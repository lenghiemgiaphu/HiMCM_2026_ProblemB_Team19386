"""Tao Literature_Verification_Register_Team19386_v1.xlsx (openpyxl). Chi ghi nhung gi da doc that; nguon chua doc = UNVERIFIED."""
import sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
out = sys.argv[1]
H = ["Source ID", "Full citation", "Source type", "Relevant claim (as stated by the source / by the team)", "Page or section", "Verification status", "Limitations", "Where the claim is used in the report", "What the team must do to verify manually"]
R = [
 ["L1", "Faramarzi, R., Houssainy, S., Bulk, A. (2024). From Chills to Thrills: Revolutionizing Energy Efficiency and Load Flexibility in Supermarket Refrigeration (Preprint). NREL/CP-5500-89884. 2024 ACEEE Summer Study on Energy Efficiency in Buildings, Pacific Grove, CA, 4-9 Aug 2024. https://www.nrel.gov/docs/fy25osti/89884.pdf (no DOI printed in the document)",
  "Conference paper (NREL preprint)", "Open vertical medium-temperature cases are said to have 'more than 80% of their cooling load attributed to infiltration of warm and moist air from the surrounding space'. Supermarket EUI ~68 kWh/sf-yr; refrigeration ~50% of supermarket electricity (read in full text, figures as relayed by the fetch tool).",
  "Page 1: Abstract and Introduction (infiltration sentence); page 1 footnote 1 (glass doors)", "VERIFIED (full text read this session; page numbers as reported by the fetch tool - confirm in the PDF viewer)",
  "Gives NO percentage of electricity saved. Glass-door retrofit is described only as able to 'yield significant energy efficiency improvements' (footnote, citing Faramarzi 2002), no number. Do not derive a saving from the 80% load share. The 80% concerns cooling LOAD of open cases, not electricity use of a store.",
  "Requirement 1 (why efficiency cannot depend on energy use alone); analogy air curtain <-> shelter openness", "Open the PDF, find the abstract sentence on page 1 and confirm wording."],
 ["L2", "Amin, Dabiri, Navaz (2011), Univ. of Washington / Navaz - 'Comprehensive study on the effects of fluid dynamics of air curtain and geometry on infiltration rate of open refrigerated cavities' (title as written by the team; journal/volume/pages NOT recorded)", "Journal article (details incomplete)", "Team note: infiltration dominates load of open cavities.", "Not read", "UNVERIFIED - fetch blocked (domain not on allowlist); only the team's paraphrase exists",
  "Bibliographic data incomplete in team file. Nothing may be quoted.", "Requirement 1 (planned)", "Open the team's URL (aa.washington.edu .../dabiri/pubs/...), record journal, year, volume, pages, DOI; find the infiltration statement and page."],
 ["L3", "Phys.org (Oct 2011), news item 'physics-grocery-cases-energy' https://phys.org/news/2011-10-physics-grocery-cases-energy.pdf", "News article", "Team note: ~75% of cooling load from infiltration; test improvement cut infiltration ~10%.", "Not read", "UNVERIFIED - fetch blocked", "Popular source; secondary to L2; author/date not recorded.", "Blog only (team plan)", "Open URL, record author/date, copy the two figures with context."],
 ["L4", "Nascimento, Heidinger, Gaspar, Silva. IIR International Congress of Refrigeration, Montreal 2019. DOI 10.18462/iir.icr.2019.0861. https://core.ac.uk/download/304001228.pdf (team file)", "Conference paper", "Team note: infiltration 67-81% of total load citing Faramarzi 1999, ASHRAE 2010, Gaspar 2011; customers' effect on air curtain.", "Not read", "UNVERIFIED - fetch blocked", "Citations inside the paper (Faramarzi 1999, ASHRAE 2010, Gaspar 2011) also unverified. Title not recorded in team file.", "Requirement 1", "Open PDF, record exact title, find the 67-81% statement and its page, check which studies it cites."],
 ["L5", "Nascimento, Heidinger, Gaspar, Silva - 'Thermal load in refrigerated display cabinets due to breakage of the air curtain'. https://core.ac.uk/download/304001304.pdf (team file; venue/year not recorded)", "Conference/journal paper", "Team note: store open vs closed raises heat gain factor and load by ~22% and ~18%; infiltration 78-81% under test conditions.", "Not read", "UNVERIFIED - fetch blocked", "Test conditions and exact definitions unknown. The team flagged this as the most useful number - do not use before reading.", "Requirement 1 (customer-effect argument)", "Open PDF, read results section, copy figures with test conditions and page; record venue/year/DOI."],
 ["L6", "Brunel University London thesis, 'Investigation of the entrainment and infiltration rates through air curtains of open low-front refrigerated display cabinets' https://bura.brunel.ac.uk/handle/2438/7456 (author/year not recorded)", "PhD thesis", "Team note: 70-80% of load due to infiltration through the air curtain.", "Not read", "UNVERIFIED - fetch blocked", "Author, year, degree not recorded.", "Requirement 1 (method)", "Open repository page, record author/year; locate the 70-80% statement and page."],
 ["L7", "JEPM (2023), 'Experimental study of the performance of open-type refrigerated display cabinet' https://jepm.tfzv.ues.rs.ba/article/id/106/ (authors/volume/pages not recorded)", "Journal article", "Team note: improved design reduces infiltration ratio 38.7%->27.7% and 24-h electricity 24.91->19.22 kWh.", "Not read", "UNVERIFIED - fetch blocked", "The only source giving an electricity saving, but it is a design-specific experiment, not a general saving from doors/lids.", "Requirement 1 (quantified example)", "Open article, record authors/volume/pages/DOI, confirm the four numbers and test conditions."],
 ["L8", "Faramarzi (2002) and 'ASHRAE 2022' as cited INSIDE L1/team note", "Secondary citations", "Cited by L1 for glass-door benefit / by team note for 80% share.", "Not read", "UNVERIFIED - not retrieved", "The team note says L1 cites ASHRAE 2022; that attribution was not checked in the L1 text.", "Do not cite directly", "Check L1 reference list on the last pages for the exact entries."],
 ["L9", "2026 HiMCM Problem B statement (team copy 2026_HiMCM_Problem_B.pdf) and Cooling_Systems_Spec_Summary.pdf (team-made, AI-assisted)", "Contest statement / internal summary", "A: perceived up to 3 C, 0.25 kW; B: air up to 5 C, 1.2 kW; C: air up to 8 C, 2.5 kW (from the problem table).", "Cooling_Systems_Spec_Summary.pdf p.1 section 1", "VERIFIED against the team's own PDF text (read in this audit); original contest PDF not re-checked line by line", "Spec summary is a team document, not independent literature; Stull wet-bulb accuracy +-1 C is the team's statement.", "Requirement 2a", "Compare against the official problem PDF table."],
]
wb = Workbook(); ws = wb.active; ws.title = "Register"
ws.append(H)
for r in R: ws.append(r)
for c in ws[1]: c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1F3864"); c.alignment = Alignment(wrap_text=True, vertical="top")
for row in ws.iter_rows(min_row=2):
    for c in row: c.alignment = Alignment(wrap_text=True, vertical="top")
    st = row[5].value
    row[5].fill = PatternFill("solid", fgColor="C6EFCE" if st.startswith("VERIFIED") else "FFC7CE")
for col, w in zip("ABCDEFGHI", (9, 55, 18, 55, 28, 32, 55, 28, 50)): ws.column_dimensions[col].width = w
ws.freeze_panes = "A2"
n = wb.create_sheet("Notes")
for l in ["Status legend: VERIFIED = full text read in this audit session; UNVERIFIED = only the team's paraphrase exists (fetch blocked or not attempted).",
          "Verification date: 16 Nov 2026. Fetch tool could read nrel.gov only; core.ac.uk, phys.org, jepm.tfzv.ues.rs.ba, bura.brunel.ac.uk, aa.washington.edu and osti.gov were not on the session allowlist.",
          "Do not convert an infiltration LOAD share into an electricity SAVING."]:
    n.append([l])
n.column_dimensions["A"].width = 160
wb.save(out)
