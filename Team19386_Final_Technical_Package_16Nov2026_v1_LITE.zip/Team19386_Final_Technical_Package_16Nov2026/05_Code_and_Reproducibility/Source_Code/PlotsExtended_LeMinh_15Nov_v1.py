"""
PlotsExtended_LeMinh_15Nov_v1.py -- HiMCM 2026 Problem B (Team #19386)
Xuất đồ thị chuẩn nhóm: 10x6 inch, dpi=300, font >= 10pt, tên theo quy tắc [NoiDung]_LeMinh_[DDMon]_[v].png
Đọc các CSV trong Output_Tables/ (do ExtendedAnalysis_ và MonteCarloV24_ tạo) và ghi vào Output_Plots/.
Biến môi trường: HIMCM_TABLES (thư mục CSV), HIMCM_PLOTS (thư mục xuất).
"""
import os
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

np.random.seed(42)
TAB = Path(os.environ.get("HIMCM_TABLES", "."))
PLT = Path(os.environ.get("HIMCM_PLOTS", "."))
PLT.mkdir(parents=True, exist_ok=True)
TAG = "LeMinh_15Nov_v1"

plt.rcParams.update({"figure.figsize": (10, 6), "font.size": 10, "axes.titlesize": 11, "axes.labelsize": 10,
                     "xtick.labelsize": 10, "ytick.labelsize": 10, "legend.fontsize": 10, "axes.grid": True,
                     "grid.alpha": 0.25, "axes.spines.top": False, "axes.spines.right": False})
COL = {"A": "#0072B2", "B": "#E69F00", "C": "#009E73", "Baseline": "#555555"}
SITE_NAME = {"Tram_Xe_Buyt": "Bus stop (Hanoi)", "Ga_Ha_Noi": "Rail station (Hanoi)",
             "San_Bay_Honolulu": "Airport (Honolulu)", "Sun_Devil_Stadium": "Stadium (Tempe, AZ)"}
SITES = list(SITE_NAME)


def rd(name):
    return pd.read_csv(TAB / f"{name}_{TAG}.csv")


def save(fig, name):
    p = PLT / f"{name}_{TAG}.png"
    fig.tight_layout()
    fig.savefig(p, dpi=300)
    plt.close(fig)
    print("saved", p.name)


# 1 ------------------------------------------------------------ chi phí vs danger (quét 120)
def fig_cost_danger():
    cr = rd("ConfigurationResults_Cap120")
    rk = rd("AHP_Ranking_Cap120")
    knee = rd("KneeAnalysis")
    for _d in (cr, rk):                      # nhiễu số học ~1e-17 -> 0
        _d.loc[_d.danger_share.abs() < 1e-9, "danger_share"] = 0.0
    knee.loc[knee.danger_share_at_knee.abs() < 1e-9, "danger_share_at_knee"] = 0.0
    fig, axs = plt.subplots(2, 2, figsize=(10, 6), sharex=False)
    for ax, s in zip(axs.ravel(), SITES):
        g = cr[cr.site == s]
        for sysm in "ABC":
            h = g[g.system == sysm].sort_values("n_units")
            ax.plot(h.EAC_USD_per_season_year / 1000, h.danger_share * 100, color=COL[sysm], lw=1.6, label=f"System {sysm}")
        b = g[g.system == "Baseline"].iloc[0]
        ax.axhline(b.danger_share * 100, color=COL["Baseline"], ls=":", lw=1.2, label="Baseline")
        t = rk[rk.site == s].sort_values("AHP_score", ascending=False).iloc[0]
        ax.scatter([t.EAC_USD_per_season_year / 1000], [t.danger_share * 100], s=70, marker="*", color="k", zorder=5,
                   label=f"AHP #1 (cap 120): {t.system}-{int(t.n_units)}")
        k = knee[(knee.site == s) & knee.knee_units.notna()]
        for _, r in k.iterrows():
            ax.scatter([r.EAC_at_knee / 1000], [r.danger_share_at_knee * 100], s=28, color=COL[r.system], edgecolor="k", zorder=4)
        ax.set_title(SITE_NAME[s])
        ax.set_xlabel("EAC (kUSD / season-year)")
        ax.set_ylabel("Danger share (%)")
        ax.legend(fontsize=8, loc="best")
    fig.suptitle("Cost vs. heat danger, 0-120 units per system (dots = knee point)", fontsize=11)
    save(fig, "CostVsDanger_Cap120")


# 2 ------------------------------------------------------------ hiệu suất
def fig_efficiency():
    cr = rd("ConfigurationResults_Cap120")
    fig, axs = plt.subplots(2, 2, figsize=(10, 6))
    for ax, s in zip(axs.ravel(), SITES):
        g = cr[(cr.site == s) & (cr.system != "Baseline")]
        for sysm in "ABC":
            h = g[g.system == sysm].sort_values("n_units")
            y = h.Eff_per_kWh.clip(lower=1e-4)
            ax.plot(h.n_units, y, color=COL[sysm], lw=1.6, label=f"System {sysm}")
        ax.set_yscale("log")
        ax.set_title(SITE_NAME[s])
        ax.set_xlabel("Units installed")
        ax.set_ylabel("Person·°C·h avoided per kWh")
        ax.legend(fontsize=8)
    fig.suptitle("Cooling efficiency (avoided heat-stress exposure per kWh)", fontsize=11)
    save(fig, "EfficiencyPerKWh")


# 3 ------------------------------------------------------------ độ nhạy: số lần đổi hạng #1
def fig_rank_tracking():
    d = rd("Sensitivity_RankTracking")
    d = d[d.variant != "BASE"].copy()
    d["col"] = d.site.map(SITE_NAME) + " | cap " + d.cap.astype(str)
    piv = d.pivot_table(index="variant", columns="col", values="rank1_changed", aggfunc="sum")
    nvals = d.groupby("variant").value.nunique()
    piv = piv.loc[piv.sum(axis=1).sort_values(ascending=False).index]
    cols = [f"{SITE_NAME[s]} | cap {c}" for s in SITES for c in (40, 120)]
    piv = piv[cols]
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.heatmap(piv, annot=True, fmt=".0f", cmap="YlOrRd", cbar_kws={"label": "# perturbed values that change AHP #1"},
                ax=ax, annot_kws={"fontsize": 9}, linewidths=0.4)
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.set_xticklabels([c.replace(" | ", ", ") for c in cols], rotation=35, ha="right", fontsize=10)
    ax.set_title("Which input changes the AHP #1 configuration? (count of perturbed values, per variant)", fontsize=11)
    save(fig, "RankTrackingHeatmap")


# 4 ------------------------------------------------------------ nắng nóng
def fig_heatwave():
    h = rd("HeatwaveScenarios")
    fig, axs = plt.subplots(1, 2, figsize=(10, 6))
    for ax, cfg, ttl in zip(axs, ["Baseline", "Official_rank1_at_40cap"], ["No cooling (baseline)", "Official AHP #1 configuration"]):
        for s in SITES:
            g = h[(h.site == s) & (h.config == cfg)].sort_values("warming_C")
            ax.plot(g.warming_C, g.danger_share * 100, marker="o", lw=1.8, label=SITE_NAME[s])
        ax.set_title(ttl)
        ax.set_xlabel("Warming added to hourly temperature (°C, constant humidity ratio)")
        ax.set_ylabel("Danger share (% of person-hours)")
        ax.legend(fontsize=8)
    fig.suptitle("Heat-wave stress test run through the V2.4.0 model", fontsize=11)
    save(fig, "HeatwaveDangerShare")


# 5 ------------------------------------------------------------ 3D surface & heatmap
def fig_surface():
    g = rd("SurfaceGrid")
    pairs = [("Ga_Ha_Noi", "B"), ("Sun_Devil_Stadium", "C"), ("Tram_Xe_Buyt", "C"), ("San_Bay_Honolulu", "B")]
    fig = plt.figure(figsize=(10, 6))
    for i, (s, sysm) in enumerate(pairs, 1):
        ax = fig.add_subplot(2, 2, i, projection="3d")
        d = g[(g.site == s) & (g.system == sysm)]
        piv = d.pivot(index="warming_C", columns="n_units", values="danger_share") * 100
        X, Y = np.meshgrid(piv.columns.to_numpy(float), piv.index.to_numpy(float))
        ax.plot_surface(X, Y, piv.to_numpy(), cmap="viridis_r", edgecolor="none", alpha=0.95)
        ax.set_title(f"{SITE_NAME[s]} - System {sysm}", fontsize=10)
        ax.set_xlabel("Units", fontsize=9, labelpad=2)
        ax.set_ylabel("Warming (°C)", fontsize=9, labelpad=2)
        ax.set_zlabel("Danger (%)", fontsize=9, labelpad=2)
        ax.tick_params(labelsize=8, pad=0)
        ax.view_init(elev=24, azim=-125)
    fig.suptitle("Danger share vs. number of units and warming", fontsize=11)
    save(fig, "Heatmap3D")

    fig, axs = plt.subplots(2, 2, figsize=(10, 6))
    for ax, (s, sysm) in zip(axs.ravel(), pairs):
        d = g[(g.site == s) & (g.system == sysm)]
        piv = d.pivot(index="warming_C", columns="n_units", values="Eff_per_kWh").iloc[:, 1:]
        sns.heatmap(piv, ax=ax, cmap="magma_r", cbar_kws={"label": "person·°C·h / kWh"},
                    xticklabels=4, yticklabels=2)
        ax.set_title(f"{SITE_NAME[s]} - System {sysm}", fontsize=10)
        ax.set_xlabel("Units")
        ax.set_ylabel("Warming (°C)")
        ax.invert_yaxis()
    fig.suptitle("Efficiency (avoided exposure per kWh) vs. units and warming", fontsize=11)
    save(fig, "HeatmapEfficiency")


# 6 ------------------------------------------------------------ Monte Carlo
def fig_mc():
    smp = pd.read_csv(TAB / f"MonteCarloSamples_{TAG}.csv.gz")
    summ = rd("MonteCarloSummary")
    fig, axs = plt.subplots(2, 2, figsize=(10, 6))
    for ax, s in zip(axs.ravel(), SITES):
        metric, lab = ("comfort_share", "Comfort share (%)") if s == "San_Bay_Honolulu" else ("danger_share", "Danger share (%)")
        g = smp[smp.site == s]
        for (sysm, n), h in g.groupby(["system", "n_units"], sort=False):
            ax.hist(h[metric] * 100, bins=40, density=True, alpha=0.5, color=COL[sysm], label=f"{sysm}-{n}" if sysm != "Baseline" else "Baseline")
        ax.set_title(SITE_NAME[s])
        ax.set_xlabel(lab)
        ax.set_ylabel("Density")
        ax.legend(fontsize=8)
    fig.suptitle("Monte Carlo (10,000 scenarios): outcome distributions on the V2.4.0 model", fontsize=11)
    save(fig, "MonteCarloPDF_Outcome")

    fig, axs = plt.subplots(2, 2, figsize=(10, 6))
    for ax, s in zip(axs.ravel(), SITES):
        g = smp[(smp.site == s) & (smp.system != "Baseline")]
        if s == "San_Bay_Honolulu":
            ax.text(0.5, 0.5, "No heat danger at baseline:\nefficiency not defined", ha="center", va="center", transform=ax.transAxes)
            ax.set_title(SITE_NAME[s]); continue
        for (sysm, n), h in g.groupby(["system", "n_units"], sort=False):
            v = h.Eff_per_kWh.dropna()
            v = v[v > 0]
            if len(v) == 0:
                continue
            ax.hist(np.log10(v), bins=40, density=True, alpha=0.5, color=COL[sysm], label=f"{sysm}-{n}")
        ax.set_title(SITE_NAME[s])
        ax.set_xlabel("log10 (person·°C·h avoided per kWh)")
        ax.set_ylabel("Density")
        ax.legend(fontsize=8)
    fig.suptitle("Monte Carlo: cooling efficiency distribution", fontsize=11)
    save(fig, "MonteCarloPDF_Efficiency")

    pr = summ[summ.metric == "P_rank1_AHP"].copy()
    pr["cfg"] = pr.system + "-" + pr.n_units.astype(str)
    fig, axs = plt.subplots(2, 2, figsize=(10, 6))
    for ax, s in zip(axs.ravel(), SITES):
        h = pr[pr.site == s]
        ax.bar(h.cfg, h["mean"] * 100, color=[COL[x] for x in h.system])
        ax.set_ylim(0, 115)
        ax.set_title(SITE_NAME[s])
        ax.set_ylabel("P(AHP rank 1) (%)")
        for i, v in enumerate(h["mean"] * 100):
            ax.text(i, v + 1.5, f"{v:.0f}", ha="center", fontsize=9)
    fig.suptitle("Monte Carlo: probability that each configuration is AHP #1", fontsize=11)
    save(fig, "MonteCarloRank1Probability")


# 7 ------------------------------------------------------------ che gió
def fig_shelter():
    d = rd("ShelterWindSweep")
    fig, axs = plt.subplots(1, 3, figsize=(10, 6), sharey=False)
    for ax, s in zip(axs, ["Tram_Xe_Buyt", "Ga_Ha_Noi", "San_Bay_Honolulu"]):
        for cfg, ls in (("Baseline", "--"), ("Official_rank1", "-")):
            g = d[(d.site == s) & (d.config == cfg)].sort_values("alpha_shelter")
            ax.plot(g.alpha_shelter, g.danger_share * 100, ls=ls, marker="o", label=cfg.replace("_", " "))
        ax.set_title(SITE_NAME[s], fontsize=10)
        ax.set_xlabel("alpha_shelter (1 = open to wind)")
        ax.set_ylabel("Danger share (%)")
        ax.legend(fontsize=8)
    fig.suptitle("Wind shelter factor vs. danger share", fontsize=11)
    save(fig, "ShelterWindSweep")


# 8 ------------------------------------------------------------ ma trận đánh đổi
def fig_tradeoff():
    cr = rd("ConfigurationResults_Cap120")
    rk = rd("AHP_Ranking_Cap120")
    off = pd.read_csv(TAB / f"EfficiencyOfOfficialRank1_{TAG}.csv")
    knee = rd("KneeAnalysis")
    rows = []
    for s in SITES:
        g = cr[cr.site == s]
        b = g[g.system == "Baseline"].iloc[0]
        o = off[off.site == s].iloc[0]
        t = rk[rk.site == s].sort_values("AHP_score", ascending=False).iloc[0]
        k = knee[(knee.site == s) & knee.knee_units.notna()].sort_values("share_of_max_benefit_at_knee", ascending=False)
        picks = [("Baseline", b), (f"Official #1 (cap 40): {o.system}-{int(o.n_units)}", o),
                 (f"AHP #1 (cap 120): {t.system}-{int(t.n_units)}", g[(g.system == t.system) & (g.n_units == t.n_units)].iloc[0])]
        if len(k):
            kk = k.iloc[0]
            picks.append((f"Knee: {kk.system}-{int(kk.knee_units)}", g[(g.system == kk.system) & (g.n_units == kk.knee_units)].iloc[0]))
        for lab, r in picks:
            rows.append(dict(site=SITE_NAME[s], cfg=lab, Danger=r.danger_share * 100, Comfort=r.comfort_share * 100,
                             EAC_k=r.EAC_USD_per_season_year / 1000, kWh_k=r.E_kWh_per_season_year / 1000))
    d = pd.DataFrame(rows)
    d["label"] = d.site + " | " + d.cfg
    m = d.set_index("label")[["Danger", "Comfort", "EAC_k", "kWh_k"]]
    m.columns = ["Danger %", "Comfort %", "EAC (kUSD)", "Energy (MWh)"]
    norm = pd.DataFrame(index=m.index)
    for c in m.columns:
        site_groups = d.site.values
        v = m[c].copy()
        for sname in np.unique(site_groups):
            idx = d.site.values == sname
            lo, hi = v[idx].min(), v[idx].max()
            norm.loc[idx, c] = 0.5 if hi - lo < 1e-9 else (v[idx] - lo) / (hi - lo)
        # đảo màu: Comfort cao là tốt; còn lại thấp là tốt -> màu xanh = tốt
        if c != "Comfort %":
            norm[c] = 1 - norm[c]
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.heatmap(norm.astype(float), annot=m.round(1), fmt="", cmap="RdYlGn", vmin=0, vmax=1, cbar=False, ax=ax,
                annot_kws={"fontsize": 9}, linewidths=0.5)
    ax.set_ylabel("")
    ax.set_yticklabels([t.get_text().replace(" | ", "\n") for t in ax.get_yticklabels()], fontsize=8, rotation=0)
    ax.set_title("Trade-off matrix (green = better within each site; numbers are actual values)", fontsize=11)
    save(fig, "TradeOffMatrix")


if __name__ == "__main__":
    fig_cost_danger(); fig_efficiency(); fig_rank_tracking(); fig_heatwave(); fig_surface(); fig_shelter(); fig_tradeoff()
    if (TAB / f"MonteCarloSamples_{TAG}.csv.gz").exists():
        fig_mc()
