"""
ModelExt_LeMinh_15Nov_v1.py -- HiMCM 2026 Problem B (Team #19386)
Lớp tiện ích bọc quanh PhysicalModel_Team19386_14Nov_v2.4.0.py (KHÔNG sửa file gốc).

Chức năng:
  load_ctx()            nạp mô hình V2.4.0, workbook thông số, dữ liệu thời tiết 4 địa điểm
  shift_weather()       kịch bản nóng lên +dT °C (giữ nguyên độ ẩm tuyệt đối => RH tự giảm)
  sweep()               quét 0..max_units cụm cho hệ A/B/C + Pareto + AHP chính thức (gọi lại hàm của nhóm)
  apply_variant()       thay đổi tham số đầu vào (nhân/đặt giá trị) cho phân tích độ nhạy
  knee_table()          điểm gãy hiệu quả chi phí – lợi ích
  heat_index_c()        Heat Index NWS (Rothfusz) để đối chiếu chỉ số AT_mod của nhóm
Mọi script ngẫu nhiên dùng seed 42.
"""
from __future__ import annotations

import importlib.util
import os
from pathlib import Path

import numpy as np
import pandas as pd

np.random.seed(42)

MODEL_PATH = os.environ.get("HIMCM_MODEL", "PhysicalModel_Team19386_14Nov_v2.4.0.py")
RUN_DIR = os.environ.get("HIMCM_RUN_DIR", ".")           # thư mục chứa 3 CSV thời tiết đúng tên mô hình yêu cầu
WORKBOOK = os.environ.get("HIMCM_WORKBOOK", "THONG_SO_THONG_NHAT_CHUAN_100_Team19386_14Nov_v2.4.0.xlsx")

SYSTEMS = ["A", "B", "C"]


def load_ctx(model_path: str = MODEL_PATH, run_dir: str = RUN_DIR, workbook: str = WORKBOOK):
    spec = importlib.util.spec_from_file_location("physical_model_v240", model_path)
    pm = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pm)
    tables = pm.load_workbook_parameters(workbook)
    sites = {}
    for s, m in pm.VENUES.items():
        df = pm.load_weather(Path(run_dir) / m["csv"], s)
        p = pm.get_venue_params(tables, m["workbook_col"])
        p["rho_water"] = pm.val(tables, "cooling", "rho_water", m["workbook_col"], 1.0)
        sites[s] = (df, p)
    return pm, tables, sites


def shift_weather(pm, df: pd.DataFrame, p: dict, dT: float) -> pd.DataFrame:
    """Nóng lên dT °C, giữ nguyên áp suất hơi nước (độ ẩm tuyệt đối) => RH giảm, bầu ướt tính lại."""
    if dT == 0:
        return df
    d = df.copy()
    T0 = d.Temp_C.to_numpy(float)
    rh0 = d.Relative_Humidity_Pct.to_numpy(float)
    pv = rh0 / 100.0 * pm.saturation_vapor_pressure_pa(T0)
    T1 = T0 + dT
    rh1 = np.clip(100.0 * pv / pm.saturation_vapor_pressure_pa(T1), 0.0, 100.0)
    d["Temp_C"], d["Relative_Humidity_Pct"] = T1, rh1
    P = pm.P0 * (1 - 2.25577e-5 * float(p["cao_do_m"])) ** 5.25588
    d["WetBulb_C"] = pm.wet_bulb_stull(T1, rh1, P)
    return d


def sweep(pm, site: str, df: pd.DataFrame, p: dict, max_units: int):
    """Trả về (tất cả cấu hình, biên Pareto, xếp hạng AHP chính thức) đúng hàm của nhóm."""
    return pm.run_site(df, p, site, max_units)


def sweep_custom(pm, site: str, df: pd.DataFrame, p: dict, max_units: int):
    """
    Giống pm.run_site nhưng có hiệu chỉnh nước/EAC theo days_year != 92
    (mô hình tính nước trên mẫu 92 ngày; ở đây nước được nhân days_year/92, đúng cách Sensitivity_Season của nhóm).
    """
    rows = [pm.simulate_configuration(df, p, site, None, 0)]
    for s in SYSTEMS:
        for n in range(1, max_units + 1):
            rows.append(pm.simulate_configuration(df, p, site, s, n))
    all_df = pd.DataFrame(rows)
    sc = float(p["days_year"]) / 92.0
    if abs(sc - 1.0) > 1e-12:
        w_old = all_df.water_L_per_season_year.to_numpy()
        all_df["water_L_per_season_year"] = w_old * sc
        all_df["EAC_USD_per_season_year"] = all_df.EAC_USD_per_season_year + w_old * (sc - 1.0) * float(p["water_price"])
    frontier = pm.pareto_filter(all_df)
    ranked = pm.add_official_ahp(frontier)
    return all_df, frontier, ranked


def rank1(ranked: pd.DataFrame) -> pd.Series:
    return ranked.sort_values("AHP_score", ascending=False).iloc[0]


# ---------------------------------------------------------------------------
# Biến thể tham số cho phân tích độ nhạy
# ---------------------------------------------------------------------------
def _recalc_crf(q):
    r, L = float(q["discount_rate"]), int(q["lifetime_yr"])
    q["CRF"] = r * (1 + r) ** L / ((1 + r) ** L - 1)


def _mult(key, lo=None, hi=None):
    def f(p, v):
        q = dict(p)
        x = float(q[key]) * v
        if lo is not None:
            x = max(lo, x)
        if hi is not None:
            x = min(hi, x)
        q[key] = x
        return q
    return f


def _set(key, recalc_crf=False):
    def f(p, v):
        q = dict(p)
        q[key] = v
        if recalc_crf:
            _recalc_crf(q)
        return q
    return f


def _capex_total(p, v):
    q = dict(p)
    for s in SYSTEMS:
        q[f"capex_{s}"] = float(q[f"capex_{s}"]) * v
        q[f"install_{s}"] = float(q[f"install_{s}"]) * v
    return q


def _acover(p, v):
    q = dict(p)
    for s in SYSTEMS:
        q[f"A_cover_{s}"] = float(q[f"A_cover_{s}"]) * v
    return q


def _nmax(p, v):
    q = dict(p)
    q["n_max_for_base"] = float(p["n_max"])   # chỉ đổi mức cắt trần, giữ nguyên mức cầu cơ sở
    q["n_max"] = float(p["n_max"]) * v
    return q


def _thr(key):
    def f(p, v):
        q = dict(p)
        q[key] = float(p[key]) + v
        return q
    return f


# (tên, hàm áp dụng, danh sách giá trị) -- ±20% theo quy ước nhóm, riêng đầu vào kém nguồn dùng khoảng rộng hơn
VARIANTS = [
    ("C_d", _mult("C_d"), [0.8, 1.2]),
    ("alpha_shelter", _mult("alpha_shelter", hi=1.0), [0.8, 1.2]),
    ("mix_eff", _mult("mix_eff", hi=1.0), [0.8, 1.2]),
    ("f_dung", _mult("f_dung", hi=1.0), [0.8, 1.2]),
    ("U_mai", _mult("U_mai"), [0.8, 1.2]),
    ("eps_evap", _mult("eps_evap", hi=1.0), [0.8, 1.2]),
    ("elec_price", _mult("elec_price"), [0.8, 1.2]),
    ("water_price", _mult("water_price"), [0.8, 1.2]),
    ("occupancy_scale", _mult("occupancy_scale"), [0.8, 1.2]),
    ("capex_install_total", _capex_total, [0.5, 0.8, 1.2, 1.5]),
    ("discount_rate", _set("discount_rate", True), [0.04, 0.10]),
    ("maint_rate_pct", _set("maint_rate"), [3.0, 8.0]),
    ("days_year", _set("days_year"), [150, 180]),
    ("theta_comf_AT", _thr("theta_comf_AT"), [-2.0, 2.0]),
    ("theta_danger_AT", _thr("theta_danger_AT"), [-2.0, 2.0]),
    ("n_max", _nmax, [0.8, 1.2]),
    ("v_min", _set("v_min"), [0.10, 0.30]),
    ("h_o", _mult("h_o"), [0.8, 1.2]),
    ("q_s", _mult("q_s"), [0.8, 1.2]),
    ("q_lat", _mult("q_lat"), [0.8, 1.2]),
    ("k_gio", _mult("k_gio"), [0.8, 1.2]),
    ("SHGC", _mult("SHGC", hi=1.0), [0.8, 1.2]),
    ("U_tuong", _mult("U_tuong"), [0.8, 1.2]),
    ("alpha_abs", _mult("alpha_abs", hi=1.0), [0.8, 1.2]),
    ("cluster", _mult("cluster"), [0.8, 1.2]),
    ("A_cover_all", _acover, [0.8, 1.2]),
    ("P_tb", _mult("P_tb"), [0.8, 1.2]),
]


def apply_variant(p: dict, name: str, value):
    for n, f, _ in VARIANTS:
        if n == name:
            return f(p, value)
    raise KeyError(name)


# ---------------------------------------------------------------------------
# Hiệu suất & điểm gãy
# ---------------------------------------------------------------------------
def add_efficiency(all_df: pd.DataFrame) -> pd.DataFrame:
    """
    Thêm chỉ số HIỆU SUẤT (Yêu cầu 2) so với baseline cùng địa điểm:
      dEDH38                = EDH38_baseline - EDH38_cấu hình       [người·°C·giờ/mùa-năm tránh được]
      Eff_per_kWh           = dEDH38 / E_kWh                        [người·°C·giờ / kWh]
      Eff_per_kUSD          = dEDH38 / (EAC/1000)                   [người·°C·giờ / 1000 USD]
      danger_pp_avoided     = (danger_base - danger) * 100          [điểm %]
      USD_per_danger_pp     = EAC / danger_pp_avoided               [USD / điểm % nguy hiểm tránh được]
    """
    out = []
    for site, g in all_df.groupby("site", sort=False):
        b = g[g.system == "Baseline"].iloc[0]
        h = g.copy()
        h["dEDH38"] = b.EDH38_person_C_h_per_season_year - h.EDH38_person_C_h_per_season_year
        h["danger_pp_avoided"] = (b.danger_share - h.danger_share) * 100
        h["comfort_pp_gained"] = (h.comfort_share - b.comfort_share) * 100
        with np.errstate(divide="ignore", invalid="ignore"):
            h["Eff_per_kWh"] = np.where(h.E_kWh_per_season_year > 0, h.dEDH38 / h.E_kWh_per_season_year, np.nan)
            h["Eff_per_kUSD"] = np.where(h.EAC_USD_per_season_year > 0, h.dEDH38 / (h.EAC_USD_per_season_year / 1000), np.nan)
            h["USD_per_danger_pp"] = np.where(h.danger_pp_avoided > 1e-9, h.EAC_USD_per_season_year / h.danger_pp_avoided, np.nan)
        out.append(h)
    return pd.concat(out, ignore_index=True)


def knee_table(all_df: pd.DataFrame) -> pd.DataFrame:
    """
    Với mỗi (địa điểm, hệ): điểm gãy n* = argmax(lợi ích chuẩn hóa - chi phí chuẩn hóa),
      lợi ích b(n) = (danger_0 - danger_n)/(danger_0 - danger_min)  ;  chi phí c(n) = (EAC_n - EAC_1)/(EAC_max - EAC_1)
    và n_sat = số cụm nhỏ nhất đạt phủ kín người (people_served_fraction = 1) nếu có.
    """
    rows = []
    for (site, system), g in all_df[all_df.system != "Baseline"].groupby(["site", "system"], sort=False):
        g = g.sort_values("n_units")
        base = all_df[(all_df.site == site) & (all_df.system == "Baseline")].iloc[0]
        d0, dmin = base.danger_share, g.danger_share.min()
        if d0 - dmin < 1e-9:   # hệ không cải thiện danger (ví dụ Honolulu)
            rows.append(dict(site=site, system=system, knee_units=np.nan, note="không giảm danger so với baseline"))
            continue
        b = (d0 - g.danger_share.to_numpy()) / (d0 - dmin)
        e = g.EAC_USD_per_season_year.to_numpy()
        c = (e - e.min()) / max(e.max() - e.min(), 1e-12)
        k = int(np.argmax(b - c))
        r = g.iloc[k]
        sat = g[g.people_served_fraction >= 0.999999]
        rows.append(dict(site=site, system=system, knee_units=int(r.n_units), danger_share_at_knee=r.danger_share,
                         danger_pp_avoided=(d0 - r.danger_share) * 100, EAC_at_knee=r.EAC_USD_per_season_year,
                         E_kWh_at_knee=r.E_kWh_per_season_year,
                         share_of_max_benefit_at_knee=float(b[k]),
                         units_to_cover_all_people=int(sat.n_units.min()) if len(sat) else np.nan,
                         note=""))
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Heat Index NWS (đối chiếu chỉ số AT_mod)
# ---------------------------------------------------------------------------
def heat_index_c(T_c, RH):
    T = np.asarray(T_c, float) * 9.0 / 5.0 + 32.0
    RH = np.asarray(RH, float)
    simple = 0.5 * (T + 61.0 + (T - 68.0) * 1.2 + RH * 0.094)
    hi = (-42.379 + 2.04901523 * T + 10.14333127 * RH - 0.22475541 * T * RH - 6.83783e-3 * T**2
          - 5.481717e-2 * RH**2 + 1.22874e-3 * T**2 * RH + 8.5282e-4 * T * RH**2 - 1.99e-6 * T**2 * RH**2)
    adj1 = np.where((RH < 13) & (T >= 80) & (T <= 112),
                    -((13 - RH) / 4.0) * np.sqrt(np.clip((17 - np.abs(T - 95.0)) / 17.0, 0, None)), 0.0)
    adj2 = np.where((RH > 85) & (T >= 80) & (T <= 87), ((RH - 85) / 10.0) * ((87 - T) / 5.0), 0.0)
    hi = np.where((simple + T) / 2.0 < 80.0, simple, hi + adj1 + adj2)
    return (hi - 32.0) * 5.0 / 9.0
