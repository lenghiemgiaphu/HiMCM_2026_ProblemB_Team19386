"""
AuditVerification_LeMinh_16Nov_v1.py -- HiMCM 2026 Problem B (Team #19386)
Kiểm toán độc lập: tính lại từ CSV chính thức / mô hình V2.4.0, KHÔNG sửa mô hình, KHÔNG chạy lại độ nhạy đầy đủ.
Ghi kết quả vào  $HIMCM_OUT/Audit/*.csv  và  Audit/audit_summary.json.
Môi trường: HIMCM_MODEL, HIMCM_RUN_DIR, HIMCM_WORKBOOK, HIMCM_OUT, HIMCM_OFFICIAL_DIR (thư mục chứa CSV chính thức V2.4.0)
"""
import glob
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

np.random.seed(42)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ModelExt_LeMinh_15Nov_v1 as X  # noqa: E402

OUT = Path(os.environ.get("HIMCM_OUT", ".")); AUD = OUT / "Audit"; AUD.mkdir(parents=True, exist_ok=True)
OFF = Path(os.environ["HIMCM_OFFICIAL_DIR"])   # thư mục có ConfigurationResults_..._v2.4.0.csv, AHP_Ranking_Official_..., Sensitivity_OAT_...
TAG = "LeMinh_16Nov_v1"
EDH = "EDH38_person_C_h_per_season_year"
S = {}


def rd(pattern):
    f = glob.glob(str(OFF / pattern))
    assert len(f) == 1, (pattern, f)
    return pd.read_csv(f[0], encoding="utf-8-sig")


def save(df, name):
    df.to_csv(AUD / f"{name}_{TAG}.csv", index=False, encoding="utf-8-sig")


cfg = rd("ConfigurationResults_Team19386_14Nov_v2.4.0.csv")
rk = rd("AHP_Ranking_Official_Team19386_14Nov_v2.4.0.csv")
PM, TABLES, SITES = X.load_ctx()
SL = list(SITES)

# ---------------------------------------------------------------- A. hiệu suất
top = rk.sort_values("AHP_score", ascending=False).groupby("site").head(1)
pdf_vals = {  # Bảng 2 của AHP_Matrix_Weights_Explanation_Team19386_15Nov_V3.0.pdf (trang 4): EDH38 baseline & cấu hình
    "Tram_Xe_Buyt": (7707.23, 4607.61), "Ga_Ha_Noi": (161367.19, 117373.47), "Sun_Devil_Stadium": (6564172.0, 4010695.0)}
rows = []
for _, t in top.iterrows():
    s = cfg[cfg.site == t.site]
    b = s[s.system == "Baseline"].iloc[0]
    x = s[(s.system == t.system) & (s.n_units == t.n_units)].iloc[0]
    d = b[EDH] - x[EDH]
    r = dict(site=t.site, system=t.system, n_units=int(t.n_units), EDH38_baseline_CSV=b[EDH], EDH38_config_CSV=x[EDH], dEDH38_CSV=d,
             kWh_season_year=x.E_kWh_per_season_year,
             Efficiency_CSV=d / x.E_kWh_per_season_year if x.E_kWh_per_season_year > 0 else np.nan)
    if t.site in pdf_vals:
        pb, pc = pdf_vals[t.site]
        r.update(EDH38_baseline_PDF_Table2=pb, EDH38_config_PDF_Table2=pc, Efficiency_from_PDF_Table2=(pb - pc) / x.E_kWh_per_season_year,
                 baseline_PDF_minus_CSV=pb - b[EDH], config_PDF_minus_CSV=pc - x[EDH])
    rows.append(r)
save(pd.DataFrame(rows), "CorrectedEfficiencyTable")
# so sánh toàn bộ ô EDH trong Bảng 2 PDF với CSV
pdf_all = {("Tram_Xe_Buyt", "Baseline", 0): 7707.23, ("Tram_Xe_Buyt", "C", 7): 4607.61, ("Tram_Xe_Buyt", "B", 14): 4962.81, ("Tram_Xe_Buyt", "A", 2): 6652.96,
           ("Ga_Ha_Noi", "Baseline", 0): 161367.19, ("Ga_Ha_Noi", "B", 40): 117373.47, ("Ga_Ha_Noi", "C", 20): 113178.41, ("Ga_Ha_Noi", "A", 40): 143781.03,
           ("San_Bay_Honolulu", "Baseline", 0): 0.0,
           ("Sun_Devil_Stadium", "Baseline", 0): 6564172.0, ("Sun_Devil_Stadium", "C", 40): 4010695.0, ("Sun_Devil_Stadium", "B", 4): 6472739.0,
           ("Sun_Devil_Stadium", "A", 1): 6563570.0}
cmp_rows = []
for (s, sy, n), v in pdf_all.items():
    c = cfg[(cfg.site == s) & (cfg.system == sy) & (cfg.n_units == n)].iloc[0]
    cmp_rows.append(dict(site=s, system=sy, n_units=n, coverage=c.coverage, EDH38_PDF_Table2=v, EDH38_CSV=c[EDH], diff=v - c[EDH],
                         match=abs(v - c[EDH]) < max(1.0, 1e-5 * abs(c[EDH]))))
cm = pd.DataFrame(cmp_rows); save(cm, "PDF_Table2_EDH_vs_CSV")
S["table2_edh_cells"] = int(len(cm)); S["table2_edh_mismatch"] = int((~cm.match).sum())

# ---------------------------------------------------------------- B. quét 120 cụm: kiểm tra nhất quán
c120 = pd.read_csv(OUT / "ConfigurationResults_Cap120_LeMinh_15Nov_v1.csv", encoding="utf-8-sig")
r120 = pd.read_csv(OUT / "AHP_Ranking_Cap120_LeMinh_15Nov_v1.csv", encoding="utf-8-sig")
chk = []
W, CR = PM.ahp_weights_official()
for s in SL:
    g = c120[c120.site == s]
    n_per = g[g.system != "Baseline"].groupby("system").n_units.agg(["min", "max", "count"])
    rr = r120[r120.site == s].sort_values("AHP_score", ascending=False)
    rec = (W["Safety"] * rr.b_safety + W["Comfort"] * rr.b_comfort + W["Cost"] * rr.b_cost + W["Energy"] * rr.b_energy)
    # đối chiếu với CSV chính thức cho n<=40
    o = cfg[(cfg.site == s) & (cfg.system != "Baseline")][["system", "n_units", "danger_share", "comfort_share", "EAC_USD_per_season_year", "E_kWh_per_season_year"]]
    m = o.merge(g[["system", "n_units", "danger_share", "comfort_share", "EAC_USD_per_season_year", "E_kWh_per_season_year"]], on=["system", "n_units"], suffixes=("_off", "_120"))
    maxdiff = max(float((m[c + "_off"] - m[c + "_120"]).abs().max()) for c in ["danger_share", "comfort_share", "EAC_USD_per_season_year", "E_kWh_per_season_year"])
    chk.append(dict(site=s, n_configs_total=len(g), n_per_system="/".join(f"{k}:{int(v['count'])}" for k, v in n_per.iterrows()), n_pareto=len(rr),
                    rank1=f"{rr.iloc[0].system}-{int(rr.iloc[0].n_units)}", score1=rr.iloc[0].AHP_score, rank2=f"{rr.iloc[1].system}-{int(rr.iloc[1].n_units)}",
                    score2=rr.iloc[1].AHP_score, margin_1_2=rr.iloc[0].AHP_score - rr.iloc[1].AHP_score,
                    n_ties_at_top=int((rr.AHP_score >= rr.iloc[0].AHP_score - 1e-12).sum()),
                    max_abs_dev_score_recomputed=float((rec.loc[rr.index] - rr.AHP_score).abs().max()),
                    n_overlap_with_official_cap40=len(m), max_abs_diff_vs_official_cap40=maxdiff, n_max_cfg=int(g.n_units.max())))
cd = pd.DataFrame(chk); save(cd, "Cap120_Verification"); S["cap120"] = cd.to_dict("records")

# ---------------------------------------------------------------- C. độ nhạy: kiểm tra mẫu số
sr = pd.read_csv(OUT / "Sensitivity_RankTracking_LeMinh_15Nov_v1.csv", encoding="utf-8-sig")
nb = sr[sr.variant != "BASE"]
den = nb.groupby(["cap", "site"]).size().rename("n_tests").reset_index()
fam = nb.groupby("variant").value.nunique().rename("n_values").reset_index()
S["sens_tests_per_cap_site"] = sorted(den.n_tests.unique().tolist()); S["sens_n_families"] = int(len(fam)); S["sens_values_per_family"] = fam.n_values.value_counts().to_dict()
S["sens_tests_per_family_total"] = int(fam.n_values.sum())
oat = rd("Sensitivity_OAT_Team19386_14Nov_v2.4.0.csv")
S["official_OAT_n_units"] = sorted(oat.n_units.unique().tolist()); S["official_OAT_rows"] = int(len(oat)); S["official_OAT_params"] = int(oat.parameter.nunique())
stad = nb[nb.site == "Sun_Devil_Stadium"].groupby("cap").agg(n_system_changed=("same_system", lambda x: int((~x).sum())), n_config_changed=("rank1_changed", "sum"),
                                                                units_seen=("rank1_units", lambda x: sorted(set(x)))).reset_index()
save(stad, "Stadium_Stability"); S["stadium"] = stad.astype(str).to_dict("records")
bus = nb[nb.site == "Tram_Xe_Buyt"].copy()
bus["cfg"] = bus.rank1_system + "-" + bus.rank1_units.astype(str)
save(bus.groupby(["cap", "cfg"]).size().rename("n_runs").reset_index(), "BusStop_Rank1_Distribution")
save(den.merge(nb.groupby(["cap", "site"]).agg(n_config_changed=("rank1_changed", "sum"), n_system_changed=("same_system", lambda x: int((~x).sum()))).reset_index()), "Sensitivity_Denominators")

# ---------------------------------------------------------------- D. trạm xe buýt: khả thi hình học
df, p = SITES["Tram_Xe_Buyt"]
floor = float(p["A_floor"])
geo = dict(L=p["L"], W=p["W"], H=p["H"], A_floor=floor, volume_m3=float(p["L"]) * float(p["W"]) * float(p["H"]), cluster=float(p["cluster"]))
feas = []
for sysm in "ABC":
    ac, vs = float(p[f"A_cover_{sysm}"]), float(p[f"V_sys_{sysm}"])
    n_full = int(np.ceil(floor / ac))
    feas.append(dict(system=sysm, A_cover_per_unit_m2=ac, A_cover_over_floor=ac / floor, n_units_for_full_coverage=n_full,
                     n_units_for_full_people_served=int(np.ceil(floor / (ac * float(p["cluster"])))),
                     V_sys_m3s_per_unit=vs, ACH_one_unit=vs * 3600 / geo["volume_m3"]))
fz = pd.DataFrame(feas); save(fz, "BusStop_Geometry")
S["bus_geometry"] = geo
rows = []
for cap in (1, 2, 3, 5, 7, 14, 20, 40, 120):
    a, f, r = X.sweep_custom(PM, "Tram_Xe_Buyt", df, p, cap)
    t = X.rank1(r)
    e = X.add_efficiency(a)
    x = e[(e.system == t.system) & (e.n_units == t.n_units)].iloc[0]
    rows.append(dict(cap=cap, rank1=f"{t.system}-{int(t.n_units)}", AHP=t.AHP_score, danger_share=t.danger_share, EAC=t.EAC_USD_per_season_year, kWh=t.E_kWh_per_season_year,
                     ACH_of_total_flow=(float(p[f"V_sys_{t.system}"]) * int(t.n_units) * 3600 / geo["volume_m3"]) if t.system in "ABC" and t.system != "Baseline" else 0.0))
save(pd.DataFrame(rows), "BusStop_Rank1_vs_Cap")
# điểm đầu tiên đạt f_cov=1 theo từng hệ & nguy hiểm tại đó và tại tối ưu cap-120
base = PM.simulate_configuration(df, p, "Tram_Xe_Buyt", None, 0)
rr = []
for sysm in "ABC":
    nf = int(fz[fz.system == sysm].n_units_for_full_coverage.iloc[0])
    for n in sorted({nf, 2 * nf, 7, 14, 42}):
        x = PM.simulate_configuration(df, p, "Tram_Xe_Buyt", sysm, n)
        rr.append(dict(system=sysm, n_units=n, coverage=x["coverage"], danger_share=x["danger_share"], EAC=x["EAC_USD_per_season_year"], kWh=x["E_kWh_per_season_year"],
                       danger_reduction_pp_vs_baseline=(base["danger_share"] - x["danger_share"]) * 100))
save(pd.DataFrame(rr), "BusStop_FullCoverage_Points")

# ---------------------------------------------------------------- E. Honolulu
cs = c120[c120.site == "San_Bay_Honolulu"]
b = cs[cs.system == "Baseline"].iloc[0]
rr = r120[r120.site == "San_Bay_Honolulu"].sort_values("AHP_score", ascending=False)
hon = []
for sy, n in (("Baseline", 0), ("B", 1), ("B", 40), ("B", 80), ("C", 120)):
    x = cs[(cs.system == sy) & (cs.n_units == n)].iloc[0]
    q = rr[(rr.system == sy) & (rr.n_units == n)]
    hon.append(dict(system=sy, n_units=n, danger_share=x.danger_share, comfort_share=x.comfort_share, dComfort_pp=(x.comfort_share - b.comfort_share) * 100,
                    EDH38=x[EDH], EAC=x.EAC_USD_per_season_year, kWh=x.E_kWh_per_season_year, water_L=x.water_L_per_season_year,
                    USD_per_comfort_pp=(x.EAC_USD_per_season_year / ((x.comfort_share - b.comfort_share) * 100)) if x.comfort_share > b.comfort_share else np.nan,
                    in_pareto=len(q) > 0, b_safety=q.b_safety.iloc[0] if len(q) else np.nan, b_comfort=q.b_comfort.iloc[0] if len(q) else np.nan,
                    b_cost=q.b_cost.iloc[0] if len(q) else np.nan, b_energy=q.b_energy.iloc[0] if len(q) else np.nan, AHP=q.AHP_score.iloc[0] if len(q) else np.nan))
save(pd.DataFrame(hon), "Honolulu_B80_Audit")
S["honolulu_weights"] = W
S["honolulu_pareto_size_cap120"] = int(len(rr)); S["honolulu_danger_max_abs"] = float(cs.danger_share.abs().max())
S["honolulu_range_comfort_pareto"] = [float(rr.comfort_share.min()), float(rr.comfort_share.max())]
S["honolulu_range_EAC_pareto"] = [float(rr.EAC_USD_per_season_year.min()), float(rr.EAC_USD_per_season_year.max())]
# ví dụ: nếu danh sách Pareto bị giới hạn <=40 thì hạng 1 là gì (chính thức)
a40, f40, r40 = X.sweep_custom(PM, "San_Bay_Honolulu", *SITES["San_Bay_Honolulu"][:2], 40)
t40 = X.rank1(r40); S["honolulu_rank1_cap40"] = f"{t40.system}-{int(t40.n_units)}"

# ---------------------------------------------------------------- F. nắng nóng: tái lập độc lập +3 °C
hw = []
for s in SL:
    d0, p0 = SITES[s]
    T0 = d0.Temp_C.to_numpy(float); R0 = d0.Relative_Humidity_Pct.to_numpy(float)
    for dT in (0.0, 1.0, 2.0, 3.0):
        # cách làm độc lập: tự viết lại (không dùng X.shift_weather)
        d1 = d0.copy()
        pv = R0 / 100 * PM.saturation_vapor_pressure_pa(T0)
        T1 = T0 + dT
        R1 = np.clip(100 * pv / PM.saturation_vapor_pressure_pa(T1), 0, 100)
        P = PM.P0 * (1 - 2.25577e-5 * float(p0["cao_do_m"])) ** 5.25588
        d1["Temp_C"], d1["Relative_Humidity_Pct"], d1["WetBulb_C"] = T1, R1, PM.wet_bulb_stull(T1, R1, P)
        x = PM.simulate_configuration(d1, p0, s, None, 0)
        y = X.shift_weather(PM, d0, p0, dT)
        z = PM.simulate_configuration(y, p0, s, None, 0)
        hw.append(dict(site=s, warming_C=dT, danger_share_independent=x["danger_share"], danger_share_ModelExt=z["danger_share"],
                       abs_diff=abs(x["danger_share"] - z["danger_share"]), comfort_share=x["comfort_share"], mean_T_out=T1.mean(), mean_RH_out=R1.mean(),
                       share_RH_clipped_100=float((R1 >= 100 - 1e-9).mean()), mean_AT_pop=x["mean_AT_population_C"], n_hours=len(d1)))
hwd = pd.DataFrame(hw); save(hwd, "Heatwave_Independent_Reproduction")
S["heatwave_max_abs_diff"] = float(hwd.abs_diff.max())
S["heatwave_plus3"] = hwd[hwd.warming_C == 3.0][["site", "danger_share_independent"]].set_index("site").danger_share_independent.to_dict()

# ---------------------------------------------------------------- H. so sánh Heat Index
hi = []
for s in SL:
    d0, p0 = SITES[s]
    T, RH = d0.Temp_C.to_numpy(float), d0.Relative_Humidity_Pct.to_numpy(float)
    N, _ = PM.occupancy_series(d0, p0)
    ghi, wind = d0.Solar_Radiation_Wm2.to_numpy(float), d0.Wind_Speed_ms.to_numpy(float)
    f_sun = 1.0 if float(p0["A_mai"]) <= 0 else max(0.0, 1.0 - float(p0["A_mai"]) / max(float(p0["A_floor"]), 1e-9))
    base = PM.simulate_configuration(d0, p0, s, None, 0)
    Tb, vbg = None, None
    HI = X.heat_index_c(T, RH)
    w = N / N.sum()
    AT_out_noSun = PM.apparent_temperature(T, RH, wind, ghi * 0, f_sun)    # AT_mod ngoài trời, bỏ bức xạ
    AT_out_sun = PM.apparent_temperature(T, RH, wind, ghi, f_sun)
    hi.append(dict(site=s, f_sun=f_sun, model_baseline_danger_share_AT_mod_ge38_zone_state=base["danger_share"],
                   NWS_HI_ge38_person_weighted=float((w * (HI >= 38)).sum()), NWS_HI_ge39p4_person_weighted=float((w * (HI >= 39.4)).sum()),
                   NWS_HI_ge38_hour_weighted=float((HI >= 38).mean()),
                   ATmod_outdoor_with_solar_ge38=float((w * (AT_out_sun >= 38)).sum()), ATmod_outdoor_no_solar_ge38=float((w * (AT_out_noSun >= 38)).sum()),
                   mean_T_out=float(T.mean()), mean_RH_out=float(RH.mean()), mean_HI=float((w * HI).sum()), mean_AT_mod_out_sun=float((w * AT_out_sun).sum()),
                   mean_AT_mod_out_nosun=float((w * AT_out_noSun).sum()), mean_Tbase_C=base["mean_Tbase_C"], mean_AT_pop_C=base["mean_AT_population_C"]))
hid = pd.DataFrame(hi); save(hid, "HeatIndex_Decomposition"); S["hi"] = hid.round(4).to_dict("records")

(AUD / f"audit_summary_{TAG}.json").write_text(json.dumps(S, indent=1, default=str, ensure_ascii=False), encoding="utf-8")
print("DONE")
