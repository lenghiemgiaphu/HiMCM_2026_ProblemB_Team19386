"""PlotsAudit_LeMinh_16Nov_v1.py -- hinh bo sung cho kiem toan (10x6 in, 300 dpi, font >=10pt). Doc CSV Audit/ ; khong tinh lai."""
import os
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np, pandas as pd
np.random.seed(42)
A = Path(os.environ["HIMCM_AUDIT"]); O = Path(os.environ["HIMCM_PLOTS"]); O.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
NM = {"Tram_Xe_Buyt": "Bus stop (Hanoi)", "Ga_Ha_Noi": "Rail station (Hanoi)", "San_Bay_Honolulu": "Airport (Honolulu)", "Sun_Devil_Stadium": "Stadium (Tempe, AZ)"}
d = pd.read_csv(A / "MC_Rank1_Frequency_Normalization_LeMinh_16Nov_v1.csv")
fig, axs = plt.subplots(2, 2, figsize=(10, 6))
for ax, s in zip(axs.ravel(), NM):
    g = d[d.site == s]
    cf = [c for c in g[g.normalization.str.startswith("pooled")].config]
    x = np.arange(len(cf)); w = 0.38
    p = [g[(g.normalization.str.startswith("pooled")) & (g.config == c)].P_rank1.iloc[0] * 100 for c in cf]
    l = [g[(g.normalization == "per-draw local min-max") & (g.config == c)].P_rank1.iloc[0] * 100 for c in cf]
    ax.bar(x - w / 2, p, w, label="pooled normalization", color="#888888"); ax.bar(x + w / 2, l, w, label="per-draw local min-max", color="#0072B2")
    det = g[g.normalization.str.startswith("deterministic")].config.iloc[0]
    ax.set_xticks(x); ax.set_xticklabels(cf); ax.set_ylim(0, 135); ax.set_ylabel("Share of 10,000 draws (%)"); ax.set_title(f"{NM[s]}  (deterministic 4-cfg: {det})")
    ax.legend(fontsize=9, loc="upper center", ncol=2)
fig.suptitle("EXPLORATORY: rank-1 frequency among 4 pre-selected configs (not an official probability)", fontsize=11)
fig.tight_layout(rect=(0, 0, 1, 0.95)); fig.savefig(O / "MonteCarloRank1Frequency_TwoNormalizations_LeMinh_16Nov_v1.png", dpi=300); plt.close(fig)

b = pd.read_csv(A / "BusStop_Rank1_vs_Cap_LeMinh_16Nov_v1.csv")
fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(b.cap, b.EAC / 1000, "o-", color="#D55E00"); ax.set_xscale("log"); ax.set_xlabel("Cluster cap used in the sweep (log scale)"); ax.set_ylabel("EAC of AHP #1 (kUSD / season-year)")
for _, r in b.iterrows():
    ax.annotate(f"{r.rank1}", (r.cap, r.EAC / 1000), textcoords="offset points", xytext=(4, 6), fontsize=10)
ax.set_title("Bus stop (floor 6.4 m2): AHP #1 keeps growing with the cap - no interior optimum", fontsize=11); ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig(O / "BusStopRank1VsCap_LeMinh_16Nov_v1.png", dpi=300); plt.close(fig)
print("ok")

# ---- hieu suat: thay panel Honolulu (hieu suat khong xac dinh vi EDH baseline = 0)
import os
C = pd.read_csv(Path(os.environ["HIMCM_TABLES"]) / "ConfigurationResults_Cap120_LeMinh_15Nov_v1.csv", encoding="utf-8-sig")
col = {"A": "#0072B2", "B": "#E69F00", "C": "#009E73"}
fig, axs = plt.subplots(2, 2, figsize=(10, 6))
for ax, s in zip(axs.ravel(), NM):
    g = C[C.site == s]
    if s == "San_Bay_Honolulu":
        ax.axis("off"); ax.text(0.5, 0.5, "Efficiency undefined:\nbaseline EDH38 = 0, so avoided\nexposure per kWh is 0 for every unit count", ha="center", va="center", fontsize=11, transform=ax.transAxes); ax.set_title(NM[s]); continue
    for sy in "ABC":
        h = g[g.system == sy].sort_values("n_units"); ax.plot(h.n_units, h.Eff_per_kWh, color=col[sy], label=f"System {sy}")
    ax.set_yscale("log"); ax.set_xlabel("Units installed"); ax.set_ylabel("Person-C-h avoided per kWh"); ax.set_title(NM[s]); ax.legend(fontsize=9); ax.grid(alpha=0.3)
fig.suptitle("EXPLORATORY efficiency metric: (EDH38 baseline - EDH38 config) / kWh, per season-year", fontsize=11)
fig.tight_layout(rect=(0, 0, 1, 0.95)); fig.savefig(O / "EfficiencyPerKWh_LeMinh_16Nov_v2.png", dpi=300); plt.close(fig)
print("ok2")
