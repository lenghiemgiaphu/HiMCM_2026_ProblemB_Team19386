"""
ExtendedAnalysis_LeMinh_15Nov_v1.py -- HiMCM 2026 Problem B (Team #19386)
Chạy các phân tích bổ sung trên mô hình V2.4.0 (không sửa mô hình, không ghi đè file V2.4.0):

  1. Quét 0..120 cụm + chỉ số hiệu suất (Yêu cầu 2) + điểm gãy hiệu quả chi phí
  2. Độ nhạy mở rộng có theo dõi THỨ HẠNG (cả giới hạn quét 40 và 120)
  3. Kịch bản nóng lên +1/+2/+3 °C chạy qua đúng mô hình (Yêu cầu 5)
  4. Quét hệ số che gió alpha_shelter (đối chiếu hiện tượng "chắn gió làm ga nóng hơn")
  5. Lưới (số cụm x nóng lên) cho đồ thị 3D/heatmap
  6. Bảng thống kê khí tượng giờ vận hành tính lại từ CSV + đối chiếu Heat Index NWS

Môi trường:  HIMCM_MODEL, HIMCM_RUN_DIR, HIMCM_WORKBOOK, HIMCM_OUT   (xem README)
"""
import os
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd

np.random.seed(42)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ModelExt_LeMinh_15Nov_v1 as X  # noqa: E402

OUT = Path(os.environ.get("HIMCM_OUT", "."))
OUT.mkdir(parents=True, exist_ok=True)
TAG = "LeMinh_15Nov_v1"
T0 = time.time()


def log(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def save(df, name):
    p = OUT / f"{name}_{TAG}.csv"
    df.to_csv(p, index=False, encoding="utf-8-sig")
    log(f"saved {p.name}  ({len(df)} rows)")


PM, TABLES, SITES = X.load_ctx()
SITE_LIST = list(SITES)


# ---------------------------------------------------------------- 1. quét 120 + hiệu suất + điểm gãy
def part1():
    allr, par, rk = [], [], []
    for s in SITE_LIST:
        df, p = SITES[s]
        a, f, r = X.sweep_custom(PM, s, df, p, 120)
        allr.append(a); par.append(f); rk.append(r)
        top = X.rank1(r)
        log(f"{s}: cap120 rank#1 = {top.system}-{int(top.n_units)} (score {top.AHP_score:.4f})")
    all_df = X.add_efficiency(pd.concat(allr, ignore_index=True))
    save(all_df, "ConfigurationResults_Cap120")
    save(pd.concat(par, ignore_index=True), "ParetoFrontier_Cap120")
    rk = pd.concat(rk, ignore_index=True)
    save(rk, "AHP_Ranking_Cap120")
    knee = X.knee_table(all_df)
    save(knee, "KneeAnalysis")
    # hiệu suất của cấu hình hạng #1 chính thức (cap 40)
    rows = []
    for s in SITE_LIST:
        df, p = SITES[s]
        a, f, r = X.sweep_custom(PM, s, df, p, 40)
        t = X.rank1(r)
        e = X.add_efficiency(a)
        row = e[(e.site == s) & (e.system == t.system) & (e.n_units == t.n_units)].iloc[0]
        rows.append(row)
    save(pd.DataFrame(rows), "EfficiencyOfOfficialRank1")
    return all_df


# ---------------------------------------------------------------- 2. độ nhạy có theo dõi thứ hạng
def _variant_task(args):
    name, value, cap = args
    out = []
    for s in SITE_LIST:
        df, p = SITES[s]
        q = p if name == "BASE" else X.apply_variant(p, name, value)
        a, f, r = X.sweep_custom(PM, s, df, q, cap)
        t = X.rank1(r)
        out.append(dict(variant=name, value=value, cap=cap, site=s, rank1_system=t.system, rank1_units=int(t.n_units),
                        rank1_score=float(t.AHP_score), rank1_danger_share=float(t.danger_share),
                        rank1_comfort_share=float(t.comfort_share), rank1_EAC=float(t.EAC_USD_per_season_year),
                        rank1_kWh=float(t.E_kWh_per_season_year)))
    return out


def part2():
    tasks = [("BASE", None, c) for c in (40, 120)]
    for name, _, vals in X.VARIANTS:
        for v in vals:
            for c in (40, 120):
                tasks.append((name, v, c))
    log(f"độ nhạy: {len(tasks)} lượt chạy x 4 địa điểm")
    with Pool(2) as pool:
        res = pool.map(_variant_task, tasks, chunksize=1)
    df = pd.DataFrame([r for sub in res for r in sub])
    base = df[df.variant == "BASE"].set_index(["cap", "site"])
    df["base_system"] = [base.loc[(c, s), "rank1_system"] for c, s in zip(df.cap, df.site)]
    df["base_units"] = [base.loc[(c, s), "rank1_units"] for c, s in zip(df.cap, df.site)]
    df["same_system"] = df.rank1_system == df.base_system
    df["rank1_changed"] = ~((df.rank1_system == df.base_system) & (df.rank1_units == df.base_units))
    save(df, "Sensitivity_RankTracking")
    summ = (df[df.variant != "BASE"].groupby(["cap", "site"])
            .agg(n_runs=("rank1_changed", "size"), n_system_changed=("same_system", lambda x: int((~x).sum())),
                 n_config_changed=("rank1_changed", "sum")).reset_index())
    save(summ, "Sensitivity_RankTracking_Summary")


# ---------------------------------------------------------------- 3. nắng nóng +dT
def part3():
    rows = []
    official = {}
    for s in SITE_LIST:
        df, p = SITES[s]
        a, f, r = X.sweep_custom(PM, s, df, p, 40)
        t = X.rank1(r)
        official[s] = (None if t.system == "Baseline" else t.system, int(t.n_units))
    for s in SITE_LIST:
        df0, p = SITES[s]
        for dT in (0.0, 1.0, 2.0, 3.0):
            df = X.shift_weather(PM, df0, p, dT)
            a, f, r = X.sweep_custom(PM, s, df, p, 120)
            a = X.add_efficiency(a)
            t = X.rank1(r)
            sys_o, n_o = official[s]
            def pick(system, n):
                m = a[(a.system == (system or "Baseline")) & (a.n_units == n)]
                return m.iloc[0]
            for label, row in (("Baseline", pick(None, 0)),
                               ("Official_rank1_at_40cap", pick(sys_o, n_o)),
                               (f"Rank1_at_this_climate_cap120", pick(t.system if t.system != "Baseline" else None, int(t.n_units)))):
                rows.append(dict(site=s, warming_C=dT, config=label, system=row.system, n_units=int(row.n_units),
                                 danger_share=row.danger_share, comfort_share=row.comfort_share,
                                 EDH38=row.EDH38_person_C_h_per_season_year, EAC=row.EAC_USD_per_season_year,
                                 kWh=row.E_kWh_per_season_year, Eff_per_kWh=row.Eff_per_kWh,
                                 mean_AT_pop_C=row.mean_AT_population_C))
        log(f"heatwave {s} done")
    save(pd.DataFrame(rows), "HeatwaveScenarios")


# ---------------------------------------------------------------- 4. che gió
def part4():
    rows = []
    for s in ("Tram_Xe_Buyt", "Ga_Ha_Noi", "San_Bay_Honolulu"):
        df, p = SITES[s]
        a, f, r = X.sweep_custom(PM, s, df, p, 40)
        t = X.rank1(r)
        for alpha in (0.2, 0.35, 0.5, 0.75, 1.0):
            q = dict(p); q["alpha_shelter"] = alpha
            for label, system, n in (("Baseline", None, 0), ("Official_rank1", None if t.system == "Baseline" else t.system, int(t.n_units))):
                x = PM.simulate_configuration(df, q, s, system, n)
                rows.append(dict(site=s, alpha_shelter=alpha, config=label, system=x["system"], n_units=n,
                                 danger_share=x["danger_share"], comfort_share=x["comfort_share"],
                                 mean_Tbase_C=x["mean_Tbase_C"], mean_AT_pop_C=x["mean_AT_population_C"]))
    save(pd.DataFrame(rows), "ShelterWindSweep")


# ---------------------------------------------------------------- 5. lưới 3D
def part5():
    pairs = [("Ga_Ha_Noi", "B"), ("Sun_Devil_Stadium", "C"), ("Tram_Xe_Buyt", "C"), ("San_Bay_Honolulu", "B")]
    rows = []
    for s, sysm in pairs:
        df0, p = SITES[s]
        for dT in np.arange(0, 3.01, 0.5):
            df = X.shift_weather(PM, df0, p, float(dT))
            base = PM.simulate_configuration(df, p, s, None, 0)
            for n in range(0, 121, 5):
                x = base if n == 0 else PM.simulate_configuration(df, p, s, sysm, n)
                dEDH = base["EDH38_person_C_h_per_season_year"] - x["EDH38_person_C_h_per_season_year"]
                rows.append(dict(site=s, system=sysm, n_units=n, warming_C=float(dT), danger_share=x["danger_share"],
                                 comfort_share=x["comfort_share"], EAC=x["EAC_USD_per_season_year"],
                                 kWh=x["E_kWh_per_season_year"], dEDH38=dEDH,
                                 Eff_per_kWh=(dEDH / x["E_kWh_per_season_year"]) if x["E_kWh_per_season_year"] > 0 else np.nan))
    save(pd.DataFrame(rows), "SurfaceGrid")


# ---------------------------------------------------------------- 6. thống kê khí tượng + Heat Index
def part6():
    st, hi_rows = [], []
    for s in SITE_LIST:
        df, p = SITES[s]
        T, RH, G = df.Temp_C.to_numpy(float), df.Relative_Humidity_Pct.to_numpy(float), df.Solar_Radiation_Wm2.to_numpy(float)
        N, _ = PM.occupancy_series(df, p)
        st.append(dict(site=s, n_hours=len(df), T_min=T.min(), T_mean=T.mean(), T_max=T.max(), RH_min=RH.min(),
                       RH_mean=RH.mean(), RH_max=RH.max(), GHI_max=G.max(), GHI_mean=G.mean(),
                       wind10_mean=df.Wind_Speed_ms.mean(), wetbulb_depression_mean=(T - df.WetBulb_C.to_numpy(float)).mean()))
        HI = X.heat_index_c(T, RH)
        base = PM.simulate_configuration(df, p, s, None, 0)
        hi_rows.append(dict(site=s, model_baseline_danger_share_ATmod38=base["danger_share"],
                            model_baseline_comfort_share_ATmod28=base["comfort_share"],
                            NWS_HI_ge32_hours=float((HI >= 32).mean()), NWS_HI_ge38_hours=float((HI >= 38).mean()),
                            NWS_HI_ge41_hours=float((HI >= 41).mean()),
                            NWS_HI_ge32_personhours=float((N * (HI >= 32)).sum() / N.sum()),
                            NWS_HI_ge38_personhours=float((N * (HI >= 38)).sum() / N.sum()),
                            NWS_HI_ge41_personhours=float((N * (HI >= 41)).sum() / N.sum())))
    save(pd.DataFrame(st), "WeatherStats_OperatingWindow")
    save(pd.DataFrame(hi_rows), "HeatIndexCrossCheck")


if __name__ == "__main__":
    which = sys.argv[1:] or ["1", "6", "3", "4", "5", "2"]
    fn = {"1": part1, "2": part2, "3": part3, "4": part4, "5": part5, "6": part6}
    for w in which:
        log(f"=== part {w} ===")
        fn[w]()
    log("DONE")
