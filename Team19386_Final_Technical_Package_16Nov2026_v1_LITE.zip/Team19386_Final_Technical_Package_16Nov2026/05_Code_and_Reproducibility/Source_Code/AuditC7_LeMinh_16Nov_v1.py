"""AuditC7_LeMinh_16Nov_v1.py -- C7 = ga Ha Noi voi alpha_shelter 0.35 -> 0.20 (inputs.py L28, L58-62 cua goi nhom). Tinh tac dong qua mo hinh V2.4.0 (khong sua mo hinh)."""
import os, sys
from pathlib import Path
import numpy as np, pandas as pd
np.random.seed(42)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ModelExt_LeMinh_15Nov_v1 as X
OUT = Path(os.environ["HIMCM_OUT"]) / "Audit"; OUT.mkdir(parents=True, exist_ok=True)
PM, T, SITES = X.load_ctx(); s = "Ga_Ha_Noi"; df, p = SITES[s]
rows = []
for a in (0.10, 0.15, 0.20, 0.25, 0.30, 0.35):
    q = dict(p); q["alpha_shelter"] = a
    b = PM.simulate_configuration(df, q, s, None, 0)
    rows.append(dict(alpha_shelter=a, config="Baseline", danger_share=b["danger_share"], comfort_share=b["comfort_share"], mean_Tbase_C=b["mean_Tbase_C"], mean_AT_pop_C=b["mean_AT_population_C"]))
    a_, f_, r_ = X.sweep_custom(PM, s, df, q, 40); t = X.rank1(r_)
    rows.append(dict(alpha_shelter=a, config=f"AHP#1_cap40={t.system}-{int(t.n_units)}", danger_share=t.danger_share, comfort_share=t.comfort_share, mean_Tbase_C=np.nan, mean_AT_pop_C=np.nan))
pd.DataFrame(rows).to_csv(OUT / "C7_RailStation_AlphaSweep_LeMinh_16Nov_v1.csv", index=False, encoding="utf-8-sig")
# C7 (0.20) so voi goc (0.35) tren MOI cau hinh A/B/C, n=0..40
d = []
q7 = dict(p); q7["alpha_shelter"] = 0.20
for sy, n in [(None, 0)] + [(sy, n) for sy in "ABC" for n in range(1, 41)]:
    x0 = PM.simulate_configuration(df, p, s, sy, n); x7 = PM.simulate_configuration(df, q7, s, sy, n)
    d.append(dict(system=sy or "Baseline", n_units=n, d_danger_pp=(x7["danger_share"] - x0["danger_share"]) * 100, d_comfort_pp=(x7["comfort_share"] - x0["comfort_share"]) * 100))
d = pd.DataFrame(d); d.to_csv(OUT / "C7_vs_Original_AllConfigs_LeMinh_16Nov_v1.csv", index=False, encoding="utf-8-sig")
print(pd.DataFrame(rows).round(4).to_string()); print(d.d_danger_pp.describe().round(3)); print((d.d_danger_pp > 0).mean())
