"""
AuditMonteCarlo_LeMinh_16Nov_v1.py -- kiểm toán Monte Carlo (KHÔNG chạy lại 10.000 kịch bản).
  1. Tái lập chính xác 1 khối 500 kịch bản (seed [42, địa điểm, khối]) và so với MonteCarloSamples đã lưu.
  2. Kiểm tra N, NaN, CI95 (chỉ là sai số Monte Carlo của trung bình).
  3. Xác suất hạng 1 với chuẩn hóa TỪNG KỊCH BẢN (đúng tinh thần AHP chính thức: min-max trong tập phương án) so với chuẩn hóa gộp.
  4. Khối lượng điểm bị chặn (clip) của các tham số có giá trị gốc sát 1; tách thành phần thời tiết / tham số của độ lệch trung bình.
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

np.random.seed(42)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import MonteCarloV24_LeMinh_15Nov_v1 as MC  # noqa: E402  (main được bảo vệ bởi __name__)

OUT = Path(os.environ["HIMCM_OUT"]); AUD = OUT / "Audit"; AUD.mkdir(exist_ok=True, parents=True)
TAG = "LeMinh_16Nov_v1"
smp = pd.read_csv(OUT / "MonteCarloSamples_LeMinh_15Nov_v1.csv.gz")
summ = pd.read_csv(OUT / "MonteCarloSummary_LeMinh_15Nov_v1.csv")
W, _ = MC.PM.ahp_weights_official()
w = np.array([W["Safety"], W["Comfort"], W["Cost"], W["Energy"]])
rep, rows_loc = [], []

# 1+2. kiểm tra cấu trúc & tái lập
cnt = smp.groupby(["site", "system", "n_units"]).draw.agg(["count", "min", "max"]).reset_index()
rep.append(dict(check="draws per (site,config) all == 10000", result=bool((cnt["count"] == 10000).all()), detail=f"{len(cnt)} configs"))
rep.append(dict(check="NaN in key columns", result=int(smp[["danger_share", "comfort_share", "EAC_USD", "kWh"]].isna().sum().sum()), detail="0 = OK"))
for si, s in enumerate(MC.SITE_LIST):
    _, _, arr = MC.chunk_task((si, 0, 500))
    mx = 0.0
    for j, (sy, n) in enumerate(MC.CONFIGS[s]):
        sub = smp[(smp.site == s) & (smp.system == sy) & (smp.n_units == n)].sort_values("draw").iloc[:500]
        mx = max(mx, float(np.abs(sub.danger_share.to_numpy() - arr[:, j, 0]).max()), float(np.abs(sub.EAC_USD.to_numpy() - arr[:, j, 5]).max()) / 1e6)
    rep.append(dict(check=f"re-run chunk 0 (500 draws) == stored samples [{s}]", result=bool(mx < 1e-9), detail=f"max abs diff = {mx:.2e}"))

# 2b. CI95: nửa độ rộng = 1.96*sd/sqrt(N) -> sai số Monte Carlo, KHÔNG phải bất định tham số/khí hậu
d = summ[summ.metric == "danger_share"].copy()
d["mean_minus_det_pp"] = (d["mean"] - d.deterministic) * 100
d["CI95_half_pp"] = d.CI95_mean_half * 100
d["sd_pp"] = d.sd * 100
d["det_inside_p2_5_97_5"] = (d.deterministic >= d.p2_5) & (d.deterministic <= d.p97_5)
d["det_inside_CI95_of_mean"] = (d.deterministic - d["mean"]).abs() <= d.CI95_mean_half
d.to_csv(AUD / f"MC_vs_Deterministic_{TAG}.csv", index=False, encoding="utf-8-sig")

# 3. P(hạng 1): chuẩn hóa gộp vs từng kịch bản
for s in MC.SITE_LIST:
    cf = MC.CONFIGS[s]
    A = np.stack([smp[(smp.site == s) & (smp.system == sy) & (smp.n_units == n)].sort_values("draw")[["danger_share", "comfort_share", "EAC_USD", "kWh"]].to_numpy()
                  for sy, n in cf], axis=1)             # (N, cfg, 4)
    def score(c, lo, hi):
        sp = np.where(hi - lo < 1e-12, 1.0, hi - lo)
        flat = (hi - lo) < 1e-12
        b = np.stack([(hi[..., 0] - c[..., 0]) / sp[..., 0], (c[..., 1] - lo[..., 1]) / sp[..., 1], (hi[..., 2] - c[..., 2]) / sp[..., 2], (hi[..., 3] - c[..., 3]) / sp[..., 3]], -1)
        b = np.where(flat, 1.0, b)
        return b @ w
    s_pool = score(A, A.min(axis=(0, 1), keepdims=True), A.max(axis=(0, 1), keepdims=True))
    s_loc = score(A, A.min(axis=1, keepdims=True), A.max(axis=1, keepdims=True))
    for name, sc in (("pooled (used in earlier draft)", s_pool), ("per-draw local min-max", s_loc)):
        win = (sc == sc.max(axis=1, keepdims=True)).astype(float); win /= win.sum(axis=1, keepdims=True)
        for j, (sy, n) in enumerate(cf):
            rows_loc.append(dict(site=s, normalization=name, config=f"{sy}-{n}", P_rank1=win[:, j].mean()))
    # tất định chính thức khi chỉ xét 4 cấu hình này (không bị cắt Pareto vì Baseline và 3 hệ)
    det = np.array([[MC.PM.simulate_configuration(*(MC.SITES[s][0], MC.SITES[s][1], s, None if sy == "Baseline" else sy, n))[k]
                     for k in ("danger_share", "comfort_share", "EAC_USD_per_season_year", "E_kWh_per_season_year")] for sy, n in cf])[None]
    sc = score(det, det.min(axis=1, keepdims=True), det.max(axis=1, keepdims=True))[0]
    rows_loc.append(dict(site=s, normalization="deterministic local (4 cfg)", config=cf[int(np.argmax(sc))][0] + f"-{cf[int(np.argmax(sc))][1]}", P_rank1=1.0))
pd.DataFrame(rows_loc).to_csv(AUD / f"MC_Rank1_Frequency_Normalization_{TAG}.csv", index=False, encoding="utf-8-sig")

# 4. khối lượng điểm bị chặn + thành phần độ lệch
rng = np.random.default_rng(42)
clip_rows = []
for s in MC.SITE_LIST:
    p0 = MC.SITES[s][1]
    for name in ("alpha_shelter", "mix_eff", "f_dung", "eps_evap"):
        base = float(p0[name]); m = rng.uniform(0.8, 1.2, 200_000)
        v = np.minimum(base * m, 1.0)
        clip_rows.append(dict(site=s, param=name, base_value=base, share_draws_clipped_at_1=float((base * m > 1.0).mean()), mean_after_clip=float(v.mean()), mean_unclipped=float((base * m).mean())))
pd.DataFrame(clip_rows).to_csv(AUD / f"MC_ClippedParameters_{TAG}.csv", index=False, encoding="utf-8-sig")

dec = []
for s in MC.SITE_LIST:
    df0, p0 = MC.SITES[s]
    det = MC.PM.simulate_configuration(df0, p0, s, None, 0)["danger_share"]
    r1 = np.random.default_rng([7, 1]); r2 = np.random.default_rng([7, 2])
    wx, px = [], []
    for _ in range(250):
        dfw = MC.make_df(s, r1)
        wx.append(MC.PM.simulate_configuration(dfw, p0, s, None, 0)["danger_share"])
        pp = MC.draw_params(s, r2)
        px.append(MC.PM.simulate_configuration(df0, pp, s, None, 0)["danger_share"])
    dec.append(dict(site=s, deterministic=det, mean_weather_only=np.mean(wx), mean_params_only=np.mean(px),
                    bias_weather_pp=(np.mean(wx) - det) * 100, bias_params_pp=(np.mean(px) - det) * 100, n_draws_each=250))
pd.DataFrame(dec).to_csv(AUD / f"MC_BiasDecomposition_{TAG}.csv", index=False, encoding="utf-8-sig")
pd.DataFrame(rep).to_csv(AUD / f"MC_Checks_{TAG}.csv", index=False, encoding="utf-8-sig")
print(pd.DataFrame(rep).to_string())
