"""
Test_Reproduction_LeMinh_16Nov_v1.py  --  HiMCM 2026 Problem B, Team #19386
Chay MOI LAN tren ban sao tam thoi; khong ghi vao 01_Official_Model.

T1  Chay that PhysicalModel V2.4.0 (--max-units 40) va so sanh 8 CSV dau ra voi CSV chinh thuc (assert_frame_equal, rtol 1e-9).
T2  (kiem thu am) Chay dung lenh trong PDF V3.0 voi TEN FILE GOC (khong co hau to (1)/(2)) -> phai that bai (FileNotFoundError).
T3  Hieu suat = (EDH_baseline - EDH_cfg)/kWh tinh lai tu CSV chinh thuc phai khop CorrectedEfficiencyTable.
T4  Hang 120 cum: moi cau hinh n<=40 trong ConfigurationResults_Cap120 phai trung CSV chinh thuc (sai so tuyet doi 0).
Cach chay (tu thu muc goc cua goi):   python3 05_Code_and_Reproducibility/Tests/Test_Reproduction_LeMinh_16Nov_v1.py
"""
import hashlib, shutil, subprocess, sys, tempfile, time
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(__file__).resolve().parents[2]
ORIG = ROOT / "01_Official_Model" / "Original_V2.4.0"
OFFC = ROOT / "01_Official_Model" / "Official_Results"
MODEL = ORIG / "PhysicalModel_Team19386_14Nov_v2.4.0.py"
WB = ORIG / "THONG_SO_THONG_NHAT_CHUAN_100_Team19386_14Nov_v2.4.0.xlsx"
WX = ORIG / "Weather_Inputs"
NEED = {"WeatherData_Ga_Ha_Noi_GiaPhu_08Nov_v1(1).csv": "WeatherData_Ga_Ha_Noi_GiaPhu_08Nov_v1.csv",
        "WeatherData_Honolulu_International_Airport_GiaPhu_08Nov_v1(1).csv": "WeatherData_Honolulu_International_Airport_GiaPhu_08Nov_v1.csv",
        "WeatherData_Sun_Devil_Stadium_GiaPhu_08Nov_v1(2).csv": "WeatherData_Sun_Devil_Stadium_GiaPhu_08Nov_v1.csv"}
OUTS = ["DataAudit", "ConfigurationResults", "ParetoFrontier", "AHP_Ranking_Official", "Sensitivity_OAT", "Sensitivity_Season", "Sensitivity_AHP_Weights", "Sensitivity_Stadium_Assumptions"]
res = []


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def report(name, ok, detail=""):
    res.append((name, ok)); print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}", flush=True)


before = {p: sha(p) for p in [MODEL, WB, *WX.glob("*.csv"), *OFFC.glob("*.csv")]}
t0 = time.time()
# ---------------- T2 (am) : ten file goc
with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    for f in WX.glob("*.csv"):
        shutil.copy(f, tmp / f.name)
    shutil.copy(WB, tmp / WB.name)
    r = subprocess.run([sys.executable, str(MODEL), "--data-dir", str(tmp), "--workbook", WB.name, "--max-units", "40"], capture_output=True, text=True)
    report("T2 original weather filenames are rejected by V2.4.0 (expected failure)", r.returncode != 0 and "FileNotFoundError" in r.stderr,
           f"(exit={r.returncode}; {r.stderr.strip().splitlines()[-1][:110] if r.stderr.strip() else ''})")
# ---------------- T1 : chay that voi ten file ma mo hinh yeu cau
with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    for need, orig in NEED.items():
        shutil.copy(WX / orig, tmp / need)
    shutil.copy(WB, tmp / WB.name)
    r = subprocess.run([sys.executable, str(MODEL), "--data-dir", str(tmp), "--workbook", WB.name, "--max-units", "40"], capture_output=True, text=True)
    report("T1a V2.4.0 exits with code 0", r.returncode == 0, f"(exit={r.returncode}, {time.time() - t0:.0f}s)")
    if r.returncode != 0:
        print(r.stderr[-800:])
    for o in OUTS:
        a = tmp / f"{o}_Team19386_14Nov_v2.4.0.csv"; b = OFFC / a.name
        try:
            pd.testing.assert_frame_equal(pd.read_csv(a, encoding="utf-8-sig"), pd.read_csv(b, encoding="utf-8-sig"), rtol=1e-9, atol=1e-9, check_exact=False)
            ok, det = True, f"({len(pd.read_csv(b))} rows)"
        except Exception as e:
            ok, det = False, str(e)[:200]
        report(f"T1b {o} == official", ok, det)
# ---------------- T3
cfg = pd.read_csv(OFFC / "ConfigurationResults_Team19386_14Nov_v2.4.0.csv", encoding="utf-8-sig")
rk = pd.read_csv(OFFC / "AHP_Ranking_Official_Team19386_14Nov_v2.4.0.csv", encoding="utf-8-sig")
tab = pd.read_csv(ROOT / "02_Extended_Analysis/Audit_Tables/CorrectedEfficiencyTable_LeMinh_16Nov_v1.csv")
E = "EDH38_person_C_h_per_season_year"
ok = True
for _, t in rk.sort_values("AHP_score", ascending=False).groupby("site").head(1).iterrows():
    if t.n_units == 0:
        continue
    s = cfg[cfg.site == t.site]; b = s[s.system == "Baseline"].iloc[0]; x = s[(s.system == t.system) & (s.n_units == t.n_units)].iloc[0]
    e = (b[E] - x[E]) / x.E_kWh_per_season_year
    ok &= abs(e - tab[tab.site == t.site].Efficiency_CSV.iloc[0]) < 1e-9
report("T3 efficiency recomputed == CorrectedEfficiencyTable", bool(ok))
# ---------------- T4
c120 = pd.read_csv(ROOT / "02_Extended_Analysis/CSV_Tables/ConfigurationResults_Cap120_LeMinh_15Nov_v1.csv", encoding="utf-8-sig")
cols = ["danger_share", "comfort_share", "EAC_USD_per_season_year", "E_kWh_per_season_year", "water_L_per_season_year", E]
m = cfg.merge(c120, on=["site", "system", "n_units"], suffixes=("_o", "_x"))
mx = max(float((m[c + "_o"] - m[c + "_x"]).abs().max()) for c in cols)
report("T4 cap-120 table reproduces official rows n<=40", len(m) == len(cfg) and mx == 0.0, f"({len(m)}/{len(cfg)} rows, max abs diff {mx:.1e})")
after = {p: sha(p) for p in before}
report("T5 official inputs/outputs unchanged by the tests (SHA-256)", before == after, f"({len(before)} files)")
print(f"\n{sum(o for _, o in res)}/{len(res)} checks passed in {time.time() - t0:.0f}s")
sys.exit(0 if all(o for _, o in res) else 1)
