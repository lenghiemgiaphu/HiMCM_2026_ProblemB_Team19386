# RELEASE STATUS: CONDITIONAL PASS (16 Nov 2026)
Gate A (integrity): official files byte-identical (SHA-256 test T5), manifest generated, no zero-byte files.
Gate B (science): efficiency, cap-120 scan, heat-wave and MC checks reproduced or re-checked; caveats documented.
Gate C (reproducibility): 13/13 executed checks; historical logs separated; Windows not tested.
Gate D (archive): final zip reopened and manifest verified (see final message).
Not PASS because unresolved: cause of PDF V3.0 Table 2 mismatches; 6/7 literature sources unread; C7 approval unresolved (DECISIONS.md absent); bus-stop physical limits unmodelled; Phu's pipeline not runnable; Windows untested.
