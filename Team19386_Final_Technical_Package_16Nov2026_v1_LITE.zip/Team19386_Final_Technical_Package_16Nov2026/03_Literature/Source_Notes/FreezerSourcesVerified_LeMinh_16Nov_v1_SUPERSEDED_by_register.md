# Freezer / refrigerated display case sources - verification status (Team #19386)

Verified by reading the full text in this session:

**Faramarzi, R., Houssainy, S., Bulk, A. (2024). From Chills to Thrills: Revolutionizing Energy Efficiency and Load Flexibility in Supermarket Refrigeration. NREL/CP-5500-89884; ACEEE Summer Study 2024.** https://nrel.gov/docs/fy25osti/89884.pdf
- Supermarket EUI roughly 68 kWh/sf-yr; refrigeration about 50% of supermarket electricity.
- Open vertical medium-temperature cases are nearly 50% of the case lineup.
- More than 80% of an open case's cooling load comes from infiltration of room air across the air curtain.
- Glass-door retrofits are said to give significant savings (citing Faramarzi 2002) but NO percentage is given; industry sees doors as a sales barrier.
- No savings percentages are reported. Do not cite this paper for "X% saved by doors/lids".

NOT verified (could not be fetched from this session - the fetch tool blocked the domains, or not attempted): Nascimento et al. (core.ac.uk 304001228, 304001304), Phys.org 2011, Brunel thesis, JEPM 2023, osti.gov/biblio/89884 landing page. Read these manually before citing any number from them.
