# Nguồn tài liệu cho Yêu cầu 1 (tủ đông/tủ mát hở trong siêu thị)

Người phụ trách: Gia Phú · Tìm ngày 11/11/2026 bằng web search · **Chưa đọc toàn văn** — chỉ dựa trên tóm tắt/đoạn trích tìm được.
Trước khi trích dẫn vào báo cáo: mở từng nguồn, đọc phần liên quan, kiểm tra con số và ghi đầy đủ tác giả/năm/tạp chí vào References.
Nội dung dưới đây là **diễn đạt lại**, không trích nguyên văn.

## Ý chính các nguồn cùng hỗ trợ (dùng cho Yêu cầu 1)
Tủ hở thất thoát lạnh chủ yếu vì không khí ấm, ẩm từ môi trường xâm nhập qua màn khí (air curtain) → năng lượng bị tiêu tốn không phải để làm lạnh sản phẩm mà để xử lý phần xâm nhập đó. Vì vậy **hiệu quả làm mát không thể chỉ đo bằng điện năng**: phải đo phần lạnh *thực sự đến được sản phẩm/người dùng* so với phần *thất thoát ra môi trường*. Đây chính là "useful_fraction" trong mô hình của nhóm và là cầu nối tự nhiên sang không gian mở/bán mở.

## Danh sách nguồn

| # | Nguồn | Điều nguồn nói (diễn đạt lại) | Dùng cho |
|---|---|---|---|
| 1 | NREL, báo cáo FY25 (OSTI 89884) — https://nrel.gov/docs/fy25osti/89884.pdf | Tủ đứng hở nhiệt độ trung bình chiếm khoảng một nửa số tủ trong siêu thị điển hình; hơn 80% tải lạnh của chúng do không khí ấm ẩm xâm nhập (dẫn ASHRAE 2022). Cũng nêu lượng điện của hệ lạnh chiếm phần lớn điện năng siêu thị (cần đọc toàn văn để lấy đúng con số). | Tỷ trọng thất thoát; động cơ cho chỉ số |
| 2 | Amin, Dabiri, Navaz (nhận bài 2011), Đại học Washington — "Comprehensive study on the effects of fluid dynamics of air curtain and geometry on infiltration rate of open refrigerated cavities" — https://www.aa.washington.edu/sites/aa/files/faculty/dabiri/pubs/Comprehensive%20Study%20On%20The%20Fluid%20Dynamics%20Of%20Air%20Curtain%20And%20Geometry%20Of%20Open%20Refrigerated%20Cavities%20On%20Infiltration%20Rate%202011.pdf | Đo xâm nhập bằng khí đánh dấu; xâm nhập phụ thuộc hình học tủ, động lực học luồng màn khí, chênh áp, nhiệt độ… (thông tin tạp chí cần lấy từ trang đầu file). | Các yếu tố ảnh hưởng hiệu quả (thiết kế, luồng khí) |
| 3 | Phys.org (2011), bản tin về nghiên cứu trên — https://phys.org/news/2011-10-physics-grocery-cases-energy.pdf | Tóm tắt phổ thông: khoảng 75% tải lạnh do không khí ấm ẩm xâm nhập; cải tiến thử nghiệm giảm khoảng 10% xâm nhập. | Giải thích cho blog (đọc dễ) |
| 4 | Nascimento, Heidinger, Gaspar, Silva, IIR International Congress of Refrigeration, Montreal 2019, DOI 10.18462/iir.icr.2019.0861 — https://core.ac.uk/download/304001228.pdf | Tải nhiệt do xâm nhập chiếm khoảng 67–81% tổng tải theo các nghiên cứu được dẫn (Faramarzi 1999, ASHRAE 2010, Gaspar 2011); ảnh hưởng của người mua hàng lên màn khí chưa được nghiên cứu nhiều. | Khoảng giá trị có nguồn |
| 5 | Nascimento, Heidinger, Gaspar, Silva — "Thermal load in refrigerated display cabinets due to breakage of the air curtain" — https://core.ac.uk/download/304001304.pdf | Khi cửa hàng mở cửa (có khách), hệ số tăng cường nhiệt và tải lạnh tăng khoảng 22% và 18% so với lúc đóng cửa; tải xâm nhập khoảng 78–81% ở điều kiện thử. | **Số người ảnh hưởng hiệu quả** → liên hệ biến "số người" |
| 6 | Luận án, Đại học Brunel London — "Investigation of the entrainment and infiltration rates through air curtains of open low-front refrigerated display cabinets" — https://bura.brunel.ac.uk/handle/2438/7456 | Ước tính 70–80% tải lạnh là do không khí xâm nhập qua màn khí; dùng khí đánh dấu và tâm trắc để định lượng. | Phương pháp đo xâm nhập |
| 7 | Tạp chí JEPM (2023) — "Experimental study of the performance of open-type refrigerated display cabinet" — https://jepm.tfzv.ues.rs.ba/article/id/106/ | Bản cải tiến giảm tỷ lệ xâm nhập từ 38,7% xuống 27,7% và điện 24 giờ từ 24,91 xuống 19,22 kWh. | Ví dụ định lượng cải thiện thiết kế |

## Gợi ý khai thác cho Yêu cầu 1 ("Should efficiency depend only on energy use?")
1. Không: phần lớn năng lượng bị tiêu cho tải xâm nhập, nên hai tủ cùng công suất có thể "làm lạnh có ích" rất khác nhau.
2. Các đại lượng nên đưa vào chỉ số (có nguồn để biện minh): tải xâm nhập/tổng tải, thiết kế màn khí và hình học, chênh nhiệt độ–độ ẩm với môi trường, **số người/hoạt động quanh tủ**, điện năng, chi phí.
3. Phép tương tự: màn khí ↔ độ hở của shelter/nhà ga; xâm nhập ↔ trao đổi không khí với ngoài trời; "lạnh đến sản phẩm" ↔ "lạnh đến người".

## Còn thiếu (chưa làm được)
- Thông số kỹ thuật cụ thể của một mẫu tủ cụ thể (công suất, dung tích) — chưa tìm; cần quyết định có thực sự cần không (đề chỉ yêu cầu lập luận khái niệm).
- Đọc toàn văn để xác nhận con số và lấy thông tin trích dẫn chính xác.
