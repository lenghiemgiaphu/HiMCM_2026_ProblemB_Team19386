# Literature/ — tài liệu tham khảo (Gia Phú)

| File | Nội dung | Trạng thái |
|---|---|---|
| `2026_HiMCM_Problem_B.pdf` | Đề thi chính thức | ✅ có |
| `freezer_case_sources.md` | Nguồn về tủ đông/mát hở (Yêu cầu 1) | ✅ danh sách nguồn · ⏳ chưa đọc toàn văn |
| `Cooling_Systems_Spec_Summary.pdf` | Tổng hợp thông số 3 hệ làm mát (A/B/C) + trần vật lý theo dữ liệu thật | ✅ (xem ghi chú nguồn trong file) |

Ghi chú: không có "tài liệu công suất" nào ngoài bảng trong đề (hệ A là quạt; B, C là máy làm mát bay hơi). Thông số thương mại thực tế (nếu cần so sánh) do Hưng Phát cung cấp trong `costs.csv`.
