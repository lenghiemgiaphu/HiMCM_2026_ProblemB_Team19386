# Team #19386 - HiMCM 2026 Problem B - Final Technical Package (16 Nov 2026)
Anonymous: only team number #19386. Release status: CONDITIONAL PASS (see RELEASE_STATUS.md).

## Layout
01_Official_Model (V2.4.0 original files + official results, unchanged) | 02_Extended_Analysis (EXPLORATORY: cap-120 scan, sensitivity, Monte Carlo, figures, audit tables) | 03_Literature (originals + verification register) | 04_Audit_and_Corrections | 05_Code_and_Reproducibility | 99_Archive (original zips).

## Requirements
Python 3.13 (tested), packages in 05_Code_and_Reproducibility/requirements.txt (numpy, pandas, matplotlib, seaborn, reportlab, openpyxl). No network needed.

## Run (from this folder) - tested
`python3 05_Code_and_Reproducibility/Tests/Test_Reproduction_LeMinh_16Nov_v1.py`
It copies the weather files to a temp folder under the names the model requires, runs V2.4.0 (`--max-units 40`), compares the 8 output CSVs, and checks the SHA-256 of the official files. Expected: 13/13 PASS in about 6 s (see Reproduction_Log.txt).
Manual model run: copy the 3 weather CSVs from 01_Official_Model/Original_V2.4.0/Weather_Inputs and the workbook into one folder, rename the weather files to
`WeatherData_Ga_Ha_Noi_GiaPhu_08Nov_v1(1).csv`, `WeatherData_Honolulu_International_Airport_GiaPhu_08Nov_v1(1).csv`, `WeatherData_Sun_Devil_Stadium_GiaPhu_08Nov_v1(2).csv`, then
`python3 PhysicalModel_Team19386_14Nov_v2.4.0.py --data-dir <folder> --workbook THONG_SO_THONG_NHAT_CHUAN_100_Team19386_14Nov_v2.4.0.xlsx --max-units 40`
(quote filenames in the shell because of the parentheses; the workbook must be inside --data-dir).
Extended scripts (02 outputs) need env vars HIMCM_MODEL, HIMCM_RUN_DIR, HIMCM_WORKBOOK, HIMCM_OUT (HIMCM_TABLES/HIMCM_PLOTS for plots) - these were run on 15 Nov (historical logs) and NOT re-run in this release except Monte Carlo chunk 0.
Monte Carlo: seed 42 via default_rng([42, site, chunk]), 80 chunks x 500 = 10,000 draws per site.

## Known caveats
Weather filename suffixes (1)/(2) are required by the model; original names preserved. Windows untested. No vectorised port and no DECISIONS.md exist in the archives. Extended-analysis numbers (cap 120, efficiency, MC, heat-wave) are exploratory, not official model outputs.

## Troubleshooting
FileNotFoundError on weather files -> filenames; "workbook not found" -> put it in --data-dir; import errors -> install requirements.

NOTE: this is the LITE zip - 99_Archive (original zips, 26 MB) omitted; SHA-256 in 99_Archive_HASHES.txt.
