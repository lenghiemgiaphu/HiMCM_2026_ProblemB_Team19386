# Correction note for PDF V3.0 (do not edit the original PDFs; make a new versioned copy)

## 1. AHP_Matrix_Weights_Explanation V3.0, Table 2 (p.4) - EDH38 column
- 7 of 13 EDH38 cells do not match ConfigurationResults_Team19386_14Nov_v2.4.0.csv (column EDH38_person_C_h_per_season_year). Mismatches: Baseline of bus stop, Hanoi, stadium; System A rows; stadium B-4. The danger %, comfort % and AHP scores in the same table DO match.
- Consequence: efficiency from the table (0.16 / 0.83 / 23.1) differs from efficiency from the CSV (0.185 / 0.820 / 15.59). Only the baseline EDH38 (numerator) differs; configuration EDH38 and kWh agree.
- Cause: NOT identified (no value in any CSV/MD/JSON/PY file matches the PDF baselines). Hypothesis only: stale or hand-typed column.
- Action: replace the EDH38 cells by the CSV values (Corrected_Efficiency_Table.csv, PDF_Table2_EDH_vs_CSV in Audit_Tables) and define efficiency explicitly = (EDH38_baseline - EDH38_config) / kWh per season-year. The metric is exploratory, not an approved model output.
- Correction of an earlier statement: the 0.16/0.83/23.1 values come from THIS table, not from Heat-Balance V3.0 Table 2.

## 2. OverallHeatBalance V3.0, Table 2 (p.2) - weather statistics
Tmax and GHImax match the model data; Tmin, Tmean and RH statistics do not (e.g. Hanoi Tmin 18.8 vs 24.5). Origin unverified. Replace by WeatherStats_OperatingWindow_LeMinh_15Nov_v1.csv (7,728 operating hours). The bus stop and Hanoi station share one weather file.

## 3. Other wording
- "NWS 38 C threshold": 38 C is the team's AT_mod threshold; NWS Danger starts at 103 F = 39.4 C. The model-vs-NWS comparison uses different metrics.
- Sensitivity: state that the official OAT ran at n_units = 1.
- Monte Carlo: quote draw-to-draw sd (2.4-3.3 pp), not "CI95 < 0.1 pp"; mean offsets are 0.05-0.90 pp, not 1-2 pp.
