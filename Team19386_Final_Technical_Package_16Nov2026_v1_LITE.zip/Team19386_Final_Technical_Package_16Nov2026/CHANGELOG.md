# Changelog (16 Nov 2026)
## Added
- 04_Audit_and_Corrections: Technical audit PDF, C7 audit PDF, corrected efficiency table, PDF V3.0 correction note.
- 02_Extended_Analysis/Audit_Tables: 20 audit tables/JSON (independent recomputations); two new figures (BusStopRank1VsCap, MC two-normalisation, EfficiencyPerKWh v2).
- 03_Literature: verification register (xlsx, 9 sources). 05: tests, audit scripts, requirements, reproduction log.
## Corrected (statements of the earlier summary)
- 0.16/0.83/23.1 come from AHP V3.0 Table 2, not Heat-Balance Table 2.
- Monte Carlo mean offset is 0.05-0.90 pp (not 1-2 pp); CI95 (<0.07 pp) is Monte Carlo error only; pooled rank-1 frequencies are artefacts, now labelled EXPLORATORY.
- C7 definition IS recoverable from code (alpha_shelter 0.35 -> 0.20) but unapproved; DECISIONS.md absent.
- MC audit label and a Vietnamese string that rendered as boxes in the PDF were replaced by ASCII text (audit PDFs rebuilt).
## Verified (executed 16 Nov)
- V2.4.0 re-run reproduces 8 official CSVs; cap-120 table reproduces official rows; SHA-256 of 15 official files unchanged; 13/13 checks.
## Not verified
- Cause of PDF Table 2 mismatches; 6 of 7 literature sources; C7 team approval; Windows execution; Phu's MC pipeline; bus-stop physical feasibility limits.
## File status
- OFFICIAL: 01_Official_Model/** (byte copies). EXPLORATORY: 02_Extended_Analysis/** (all labelled). ARCHIVED: 99_Archive, Figures_300dpi/_superseded, Historical_Logs.
